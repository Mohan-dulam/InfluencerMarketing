import { useState, useEffect, useCallback } from 'react'
import { supabase, Influencer } from '@/lib/supabase'

interface Filters {
  search: string
  niche: string
  platform: string
  sortBy: 'followers' | 'engagement_rate' | 'rating' | 'fee_per_post'
}

export function useInfluencers() {
  const [influencers, setInfluencers] = useState<Influencer[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [filters, setFilters] = useState<Filters>({
    search: '',
    niche: 'All',
    platform: 'All',
    sortBy: 'followers',
  })

  const fetch = useCallback(async () => {
    setLoading(true)
    setError(null)

    let query = supabase
      .from('influencers')
      .select('*')
      .eq('is_active', true)
      .order(filters.sortBy, { ascending: false })

    if (filters.search) {
      query = query.or(`name.ilike.%${filters.search}%,handle.ilike.%${filters.search}%`)
    }
    if (filters.niche !== 'All') {
      query = query.eq('niche', filters.niche)
    }
    if (filters.platform !== 'All') {
      query = query.eq('platform', filters.platform)
    }

    const { data, error: err } = await query
    if (err) { setError(err.message); setLoading(false); return }
    setInfluencers(data as Influencer[])
    setLoading(false)
  }, [filters])

  useEffect(() => { fetch() }, [fetch])

  return { influencers, loading, error, filters, setFilters, refetch: fetch }
}
