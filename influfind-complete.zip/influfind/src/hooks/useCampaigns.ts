import { useState, useEffect, useCallback } from 'react'
import { supabase, Campaign } from '@/lib/supabase'
import { useAuth } from '@/context/AuthContext'
import toast from 'react-hot-toast'

export function useCampaigns() {
  const { user } = useAuth()
  const [campaigns, setCampaigns] = useState<Campaign[]>([])
  const [loading, setLoading] = useState(true)

  const fetch = useCallback(async () => {
    if (!user) return
    setLoading(true)
    const { data, error } = await supabase
      .from('campaigns')
      .select('*, influencer:influencer_id(*)')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
    if (!error) setCampaigns(data as Campaign[])
    setLoading(false)
  }, [user])

  useEffect(() => { fetch() }, [fetch])

  // Realtime subscription
  useEffect(() => {
    if (!user) return
    const sub = supabase
      .channel('campaigns-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'campaigns', filter: `user_id=eq.${user.id}` },
        () => fetch())
      .subscribe()
    return () => { supabase.removeChannel(sub) }
  }, [user, fetch])

  const createCampaign = async (data: Omit<Campaign, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => {
    if (!user) return
    const { error } = await supabase.from('campaigns').insert({ ...data, user_id: user.id })
    if (error) { toast.error(error.message); return }
    toast.success('Campaign created!')
    await fetch()
  }

  const updateCampaign = async (id: string, updates: Partial<Campaign>) => {
    const { error } = await supabase.from('campaigns').update(updates).eq('id', id)
    if (error) { toast.error(error.message); return }
    toast.success('Campaign updated!')
    await fetch()
  }

  const deleteCampaign = async (id: string) => {
    const { error } = await supabase.from('campaigns').delete().eq('id', id)
    if (error) { toast.error(error.message); return }
    toast.success('Campaign deleted')
    await fetch()
  }

  const markComplete = async (id: string) => {
    await updateCampaign(id, { status: 'completed', progress: 100 })
  }

  return { campaigns, loading, createCampaign, updateCampaign, deleteCampaign, markComplete, refetch: fetch }
}
