import { useState, useEffect, useCallback } from 'react'
import { supabase, Message } from '@/lib/supabase'
import { useAuth } from '@/context/AuthContext'
import toast from 'react-hot-toast'

export function useMessages(campaignId: string | null) {
  const { user, profile } = useAuth()
  const [messages, setMessages] = useState<Message[]>([])
  const [loading, setLoading] = useState(false)

  const fetch = useCallback(async () => {
    if (!campaignId) return
    setLoading(true)
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .eq('campaign_id', campaignId)
      .order('created_at', { ascending: true })
    if (!error) setMessages(data as Message[])
    setLoading(false)
  }, [campaignId])

  useEffect(() => { fetch() }, [fetch])

  // Realtime
  useEffect(() => {
    if (!campaignId) return
    const channel = supabase
      .channel(`messages-${campaignId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `campaign_id=eq.${campaignId}` },
        (payload) => setMessages(prev => [...prev, payload.new as Message]))
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [campaignId])

  const sendMessage = async (content: string) => {
    if (!user || !campaignId || !content.trim()) return
    const { error } = await supabase.from('messages').insert({
      campaign_id: campaignId,
      sender_id: user.id,
      sender_name: profile?.full_name || user.email || 'You',
      sender_avatar: profile?.avatar_url,
      content: content.trim(),
    })
    if (error) toast.error('Failed to send message')
  }

  return { messages, loading, sendMessage }
}
