import { useState, useEffect, useCallback } from 'react'
import { supabase, ContentHistory } from '@/lib/supabase'
import { useAuth } from '@/context/AuthContext'
import toast from 'react-hot-toast'

export function useContentHistory() {
  const { user } = useAuth()
  const [history, setHistory] = useState<ContentHistory[]>([])
  const [loading, setLoading] = useState(true)

  const fetch = useCallback(async () => {
    if (!user) return
    setLoading(true)
    const { data, error } = await supabase
      .from('content_history')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(50)
    if (!error) setHistory(data as ContentHistory[])
    setLoading(false)
  }, [user])

  useEffect(() => { fetch() }, [fetch])

  const saveContent = async (params: {
    campaign_name?: string
    brand_name?: string
    tone?: string
    content_type: ContentHistory['content_type']
    prompt?: string
    generated: string[]
  }) => {
    if (!user) return
    const { error } = await supabase.from('content_history').insert({
      ...params,
      user_id: user.id,
    })
    if (error) { toast.error('Failed to save content'); return }
    await fetch()
  }

  const deleteHistory = async (id: string) => {
    await supabase.from('content_history').delete().eq('id', id)
    setHistory(prev => prev.filter(h => h.id !== id))
    toast.success('Deleted from history')
  }

  return { history, loading, saveContent, deleteHistory, refetch: fetch }
}
