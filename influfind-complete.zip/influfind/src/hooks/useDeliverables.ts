import { useState, useEffect, useCallback } from 'react'
import { supabase, Deliverable } from '@/lib/supabase'
import { useAuth } from '@/context/AuthContext'
import toast from 'react-hot-toast'

export function useDeliverables(campaignId: string | null) {
  const { user } = useAuth()
  const [deliverables, setDeliverables] = useState<Deliverable[]>([])
  const [uploading, setUploading] = useState(false)

  const fetch = useCallback(async () => {
    if (!campaignId) return
    const { data, error } = await supabase
      .from('deliverables')
      .select('*')
      .eq('campaign_id', campaignId)
      .order('created_at', { ascending: false })
    if (!error) setDeliverables(data as Deliverable[])
  }, [campaignId])

  useEffect(() => { fetch() }, [fetch])

  const upload = async (file: File) => {
    if (!user || !campaignId) return
    setUploading(true)
    try {
      const ext = file.name.split('.').pop()
      const path = `${campaignId}/${Date.now()}.${ext}`
      const { error: uploadError } = await supabase.storage
        .from('deliverables')
        .upload(path, file)
      if (uploadError) throw uploadError

      const { data: urlData } = supabase.storage.from('deliverables').getPublicUrl(path)

      const { error: dbError } = await supabase.from('deliverables').insert({
        campaign_id: campaignId,
        uploader_id: user.id,
        file_name: file.name,
        file_url: urlData.publicUrl,
        file_type: file.type,
        file_size: file.size,
      })
      if (dbError) throw dbError

      toast.success('Deliverable uploaded!')
      await fetch()
    } catch (err: any) {
      toast.error(err.message || 'Upload failed')
    } finally {
      setUploading(false)
    }
  }

  const updateStatus = async (id: string, status: 'approved' | 'rejected') => {
    const { error } = await supabase.from('deliverables').update({ status }).eq('id', id)
    if (!error) await fetch()
  }

  return { deliverables, uploading, upload, updateStatus }
}
