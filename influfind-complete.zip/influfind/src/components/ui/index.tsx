import React, { useState, forwardRef } from 'react'
import { clsx } from 'clsx'

// ─── DESIGN TOKENS ───────────────────────────────────────────────────────────
export const T = {
  violet: '#8B5CF6',
  violetLight: '#A78BFA',
  violetDark: '#6D28D9',
  emerald: '#10B981',
  amber: '#F59E0B',
  rose: '#F43F5E',
  sky: '#38BDF8',
  text: '#F8FAFC',
  textMuted: 'rgba(248,250,252,0.55)',
  textFaint: 'rgba(248,250,252,0.28)',
  border: 'rgba(255,255,255,0.08)',
  borderHover: 'rgba(255,255,255,0.16)',
  surface: 'rgba(255,255,255,0.04)',
}

// ─── CHIP / BADGE ─────────────────────────────────────────────────────────────
interface ChipProps {
  children: React.ReactNode
  color?: string
  size?: 'sm' | 'md'
  className?: string
}
export const Chip: React.FC<ChipProps> = ({ children, color = T.violet, size = 'md', className }) => (
  <span
    className={clsx('inline-flex items-center font-bold tracking-wide whitespace-nowrap', className)}
    style={{
      background: color + '22',
      color,
      fontSize: size === 'sm' ? 10 : 11,
      padding: size === 'sm' ? '2px 8px' : '3px 10px',
      borderRadius: 20,
      border: `1px solid ${color}44`,
      letterSpacing: 0.3,
    }}
  >
    {children}
  </span>
)

// ─── STATUS PILL ──────────────────────────────────────────────────────────────
export const StatusPill: React.FC<{ status: string }> = ({ status }) => {
  const map: Record<string, [string, string]> = {
    active: [T.emerald, '● Live'],
    completed: [T.sky, '✓ Done'],
    pending: [T.amber, '◌ Pending'],
    paused: [T.textFaint, '⏸ Paused'],
    cancelled: [T.rose, '✕ Cancelled'],
  }
  const [color, label] = map[status] || [T.textFaint, status]
  return <Chip color={color}>{label}</Chip>
}

// ─── AVATAR ───────────────────────────────────────────────────────────────────
interface AvatarProps {
  src?: string | null
  name?: string
  size?: number
  ring?: string
  className?: string
}
export const Avatar: React.FC<AvatarProps> = ({ src, name = '', size = 40, ring, className }) => {
  const initials = name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()
  if (!src) {
    return (
      <div
        className={clsx('flex items-center justify-center font-bold rounded-full flex-shrink-0', className)}
        style={{ width: size, height: size, background: T.violet + '33', color: T.violetLight, fontSize: size * 0.35, border: ring ? `2px solid ${ring}` : `2px solid rgba(255,255,255,0.12)` }}
      >
        {initials}
      </div>
    )
  }
  return (
    <img
      src={src}
      alt={name}
      className={clsx('rounded-full object-cover flex-shrink-0', className)}
      style={{ width: size, height: size, border: ring ? `2px solid ${ring}` : '2px solid rgba(255,255,255,0.12)' }}
    />
  )
}

// ─── GLASS CARD ───────────────────────────────────────────────────────────────
interface GlassCardProps {
  children: React.ReactNode
  className?: string
  style?: React.CSSProperties
  onClick?: () => void
  hover?: boolean
  delay?: number
  active?: boolean
}
export const GlassCard: React.FC<GlassCardProps> = ({
  children, className, style = {}, onClick, hover = true, delay = 0, active = false,
}) => {
  const [hov, setHov] = useState(false)
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => hover && setHov(true)}
      onMouseLeave={() => setHov(false)}
      className={clsx('animate-fade-up', className)}
      style={{
        background: active ? 'rgba(139,92,246,0.12)' : hov ? 'rgba(255,255,255,0.065)' : 'rgba(255,255,255,0.04)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        border: active ? '1px solid rgba(139,92,246,0.35)' : hov ? `1px solid ${T.borderHover}` : `1px solid ${T.border}`,
        borderRadius: 20,
        padding: '22px 24px',
        transition: 'all 0.25s cubic-bezier(.22,1,.36,1)',
        transform: hover && hov ? 'translateY(-3px)' : 'none',
        boxShadow: hover && hov ? '0 20px 60px rgba(0,0,0,0.35)' : 'none',
        cursor: onClick ? 'pointer' : 'default',
        animationDelay: `${delay}ms`,
        animationFillMode: 'both',
        ...style,
      }}
    >
      {children}
    </div>
  )
}

// ─── BUTTON ───────────────────────────────────────────────────────────────────
interface BtnProps {
  children: React.ReactNode
  onClick?: (e: React.MouseEvent) => void
  variant?: 'primary' | 'ghost' | 'danger' | 'success' | 'outline'
  size?: 'sm' | 'md' | 'lg'
  disabled?: boolean
  loading?: boolean
  type?: 'button' | 'submit'
  className?: string
  style?: React.CSSProperties
  fullWidth?: boolean
}
export const Btn: React.FC<BtnProps> = ({
  children, onClick, variant = 'primary', size = 'md', disabled, loading, type = 'button', className, style = {}, fullWidth,
}) => {
  const [hov, setHov] = useState(false)

  const sizes = { sm: { padding: '7px 16px', fontSize: 13 }, md: { padding: '10px 22px', fontSize: 14 }, lg: { padding: '13px 28px', fontSize: 15 } }
  const variants: Record<string, React.CSSProperties> = {
    primary: { background: hov ? '#7C3AED' : 'linear-gradient(135deg,#8B5CF6,#6D28D9)', color: '#fff', border: '1px solid rgba(139,92,246,0.5)' },
    ghost: { background: hov ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.04)', color: T.text, border: `1px solid ${T.border}` },
    outline: { background: 'transparent', color: T.violetLight, border: `1px solid ${T.violet}` },
    danger: { background: hov ? '#DC2626' : '#EF4444', color: '#fff', border: 'none' },
    success: { background: hov ? '#059669' : '#10B981', color: '#fff', border: 'none' },
  }

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled || loading}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      className={clsx('inline-flex items-center justify-center gap-2 font-semibold rounded-xl transition-all', className)}
      style={{
        ...variants[variant],
        ...sizes[size],
        borderRadius: 12,
        fontFamily: "'Satoshi', sans-serif",
        cursor: disabled || loading ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1,
        transform: hov && !disabled ? 'scale(1.02)' : 'scale(1)',
        width: fullWidth ? '100%' : undefined,
        ...style,
      }}
    >
      {loading ? (
        <>
          <span style={{ width: 14, height: 14, border: '2px solid currentColor', borderTopColor: 'transparent', borderRadius: '50%', display: 'inline-block', animation: 'spin 0.7s linear infinite' }} />
          Loading…
        </>
      ) : children}
    </button>
  )
}

// ─── INPUT ────────────────────────────────────────────────────────────────────
interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string
  error?: string
  icon?: React.ReactNode
}
export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, icon, className, style, ...props }, ref) => (
    <div className="flex flex-col gap-2">
      {label && (
        <label style={{ fontSize: 11, fontWeight: 700, color: T.textFaint, letterSpacing: 1 }}>
          {label.toUpperCase()}
        </label>
      )}
      <div style={{ position: 'relative' }}>
        {icon && (
          <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: T.textFaint, fontSize: 16 }}>
            {icon}
          </span>
        )}
        <input
          ref={ref}
          className={clsx(className)}
          style={{
            width: '100%',
            background: 'rgba(255,255,255,0.05)',
            border: error ? '1px solid #EF4444' : `1px solid ${T.border}`,
            borderRadius: 12,
            color: T.text,
            padding: icon ? '10px 14px 10px 36px' : '10px 14px',
            fontSize: 14,
            outline: 'none',
            fontFamily: "'Satoshi', sans-serif",
            transition: 'border 0.2s',
            ...style,
          }}
          {...props}
        />
      </div>
      {error && <span style={{ fontSize: 12, color: '#EF4444' }}>{error}</span>}
    </div>
  )
)
Input.displayName = 'Input'

// ─── TEXTAREA ─────────────────────────────────────────────────────────────────
interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string
  error?: string
}
export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ label, error, style, ...props }, ref) => (
    <div className="flex flex-col gap-2">
      {label && (
        <label style={{ fontSize: 11, fontWeight: 700, color: T.textFaint, letterSpacing: 1 }}>
          {label.toUpperCase()}
        </label>
      )}
      <textarea
        ref={ref}
        style={{
          width: '100%',
          background: 'rgba(255,255,255,0.05)',
          border: error ? '1px solid #EF4444' : `1px solid ${T.border}`,
          borderRadius: 12,
          color: T.text,
          padding: '10px 14px',
          fontSize: 14,
          outline: 'none',
          fontFamily: "'Satoshi', sans-serif",
          resize: 'vertical',
          minHeight: 80,
          ...style,
        }}
        {...props}
      />
      {error && <span style={{ fontSize: 12, color: '#EF4444' }}>{error}</span>}
    </div>
  )
)
Textarea.displayName = 'Textarea'

// ─── SELECT ───────────────────────────────────────────────────────────────────
interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string
  options: { value: string; label: string }[]
}
export const Select: React.FC<SelectProps> = ({ label, options, style, ...props }) => (
  <div className="flex flex-col gap-2">
    {label && <label style={{ fontSize: 11, fontWeight: 700, color: T.textFaint, letterSpacing: 1 }}>{label.toUpperCase()}</label>}
    <select
      style={{
        width: '100%',
        background: 'rgba(15,14,23,0.9)',
        border: `1px solid ${T.border}`,
        borderRadius: 12,
        color: T.text,
        padding: '10px 14px',
        fontSize: 14,
        outline: 'none',
        fontFamily: "'Satoshi', sans-serif",
        cursor: 'pointer',
        ...style,
      }}
      {...props}
    >
      {options.map(o => <option key={o.value} value={o.value} style={{ background: '#1a1033' }}>{o.label}</option>)}
    </select>
  </div>
)

// ─── TOGGLE ───────────────────────────────────────────────────────────────────
export const Toggle: React.FC<{ value: boolean; onChange: (v: boolean) => void; label?: string; description?: string }> = ({
  value, onChange, label, description,
}) => (
  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 0', borderBottom: `1px solid ${T.border}` }}>
    {(label || description) && (
      <div>
        {label && <div style={{ fontWeight: 600, fontSize: 14 }}>{label}</div>}
        {description && <div style={{ fontSize: 12, color: T.textFaint, marginTop: 3 }}>{description}</div>}
      </div>
    )}
    <div
      onClick={() => onChange(!value)}
      style={{
        width: 46, height: 26, borderRadius: 13,
        background: value ? 'linear-gradient(135deg,#8B5CF6,#6D28D9)' : 'rgba(255,255,255,0.1)',
        border: `1px solid ${T.border}`, position: 'relative', cursor: 'pointer',
        transition: 'all 0.25s', flexShrink: 0,
      }}
    >
      <div style={{
        position: 'absolute', top: 3, left: value ? 22 : 3, width: 18, height: 18,
        borderRadius: '50%', background: '#fff',
        transition: 'left 0.25s cubic-bezier(.22,1,.36,1)',
        boxShadow: '0 2px 8px rgba(0,0,0,0.3)',
      }} />
    </div>
  </div>
)

// ─── PROGRESS BAR ─────────────────────────────────────────────────────────────
export const ProgressBar: React.FC<{ value: number; color?: string; height?: number; showLabel?: boolean }> = ({
  value, color = T.violet, height = 5, showLabel,
}) => (
  <div>
    {showLabel && (
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
        <span style={{ fontSize: 12, color: T.textFaint }}>Progress</span>
        <span style={{ fontSize: 12, color, fontWeight: 700 }}>{value}%</span>
      </div>
    )}
    <div style={{ background: 'rgba(255,255,255,0.06)', borderRadius: 99, height, overflow: 'hidden' }}>
      <div style={{ width: `${value}%`, height: '100%', background: `linear-gradient(90deg,${color},${color}bb)`, borderRadius: 99, transition: 'width 1s cubic-bezier(.22,1,.36,1)' }} />
    </div>
  </div>
)

// ─── PROGRESS ARC ─────────────────────────────────────────────────────────────
export const ProgressArc: React.FC<{ value: number; size?: number; stroke?: number; color?: string }> = ({
  value, size = 64, stroke = 5, color = T.violet,
}) => {
  const r = (size - stroke * 2) / 2
  const circ = 2 * Math.PI * r
  const offset = circ - (value / 100) * circ
  return (
    <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={stroke} />
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke}
        strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round"
        style={{ transition: 'stroke-dashoffset 1s cubic-bezier(.22,1,.36,1)' }} />
    </svg>
  )
}

// ─── LOADER ───────────────────────────────────────────────────────────────────
export const Loader: React.FC<{ size?: number; text?: string }> = ({ size = 40, text }) => (
  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 60, gap: 14 }}>
    <div style={{ width: size, height: size, border: `3px solid rgba(139,92,246,0.2)`, borderTop: `3px solid #8B5CF6`, borderRadius: '50%', animation: 'spin 0.7s linear infinite' }} />
    {text && <span style={{ color: T.textFaint, fontSize: 13, letterSpacing: 0.5 }}>{text}</span>}
  </div>
)

// ─── EMPTY STATE ─────────────────────────────────────────────────────────────
export const EmptyState: React.FC<{ icon?: string; title: string; description?: string; action?: React.ReactNode }> = ({
  icon = '◇', title, description, action,
}) => (
  <div style={{ textAlign: 'center', padding: '60px 20px' }}>
    <div style={{ fontSize: 48, marginBottom: 14, opacity: 0.3 }}>{icon}</div>
    <div style={{ fontFamily: "'Cabinet Grotesk', sans-serif", fontWeight: 800, fontSize: 20, marginBottom: 8 }}>{title}</div>
    {description && <div style={{ color: T.textMuted, fontSize: 14, marginBottom: 20 }}>{description}</div>}
    {action}
  </div>
)

// ─── MODAL ────────────────────────────────────────────────────────────────────
export const Modal: React.FC<{ open: boolean; onClose: () => void; children: React.ReactNode; maxWidth?: number }> = ({
  open, onClose, children, maxWidth = 560,
}) => {
  if (!open) return null
  return (
    <div
      onClick={onClose}
      style={{ position: 'fixed', inset: 0, background: 'rgba(5,5,7,0.8)', zIndex: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20, backdropFilter: 'blur(12px)', animation: 'fadeIn 0.2s ease' }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{ width: '100%', maxWidth, background: 'rgba(20,18,35,0.97)', border: `1px solid ${T.border}`, borderRadius: 24, maxHeight: '90vh', overflowY: 'auto', animation: 'fadeUp 0.3s cubic-bezier(.22,1,.36,1)' }}
      >
        {children}
      </div>
    </div>
  )
}

// ─── PAGE HEADER ─────────────────────────────────────────────────────────────
export const PageHeader: React.FC<{ title: string; subtitle?: string; action?: React.ReactNode }> = ({
  title, subtitle, action,
}) => (
  <div className="animate-fade-up" style={{ marginBottom: 32, display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 16 }}>
    <div>
      <h1 style={{ fontFamily: "'Cabinet Grotesk', sans-serif", fontWeight: 900, fontSize: 32, lineHeight: 1.1, background: 'linear-gradient(135deg,#fff 40%,#A78BFA)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', marginBottom: subtitle ? 8 : 0 }}>
        {title}
      </h1>
      {subtitle && <p style={{ color: T.textMuted, fontSize: 15 }}>{subtitle}</p>}
    </div>
    {action}
  </div>
)

// ─── DIVIDER ─────────────────────────────────────────────────────────────────
export const Divider: React.FC = () => (
  <div style={{ height: 1, background: T.border, margin: '20px 0' }} />
)

// ─── STAT CARD ────────────────────────────────────────────────────────────────
export const StatCard: React.FC<{ label: string; value: string; sub?: string; icon: string; color: string; delay?: number }> = ({
  label, value, sub, icon, color, delay = 0,
}) => (
  <GlassCard delay={delay} style={{ padding: '20px 22px' }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
      <div>
        <div style={{ fontSize: 11, color: T.textFaint, fontWeight: 700, letterSpacing: 1, marginBottom: 8 }}>{label.toUpperCase()}</div>
        <div style={{ fontFamily: "'Cabinet Grotesk', sans-serif", fontSize: 30, fontWeight: 900, color: '#fff', lineHeight: 1 }}>{value}</div>
        {sub && <div style={{ fontSize: 12, color, marginTop: 6, fontWeight: 500 }}>{sub}</div>}
      </div>
      <div style={{ width: 44, height: 44, background: color + '1a', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, border: `1px solid ${color}33` }}>
        {icon}
      </div>
    </div>
  </GlassCard>
)
