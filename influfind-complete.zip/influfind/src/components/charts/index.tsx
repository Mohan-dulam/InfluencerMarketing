import React from 'react'
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line,
} from 'recharts'
import { T } from '@/components/ui'

// ─── CUSTOM TOOLTIP ───────────────────────────────────────────────────────────
const CustomTooltip: React.FC<any> = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div style={{ background: 'rgba(20,18,35,0.97)', border: `1px solid ${T.border}`, borderRadius: 12, padding: '10px 14px', backdropFilter: 'blur(20px)' }}>
      {label && <div style={{ fontSize: 12, color: T.textFaint, marginBottom: 6 }}>{label}</div>}
      {payload.map((p: any) => (
        <div key={p.name} style={{ fontSize: 14, fontWeight: 700, color: p.color || T.violet }}>
          {p.name && <span style={{ color: T.textMuted, fontWeight: 400, marginRight: 6 }}>{p.name}:</span>}
          {typeof p.value === 'number' && p.value > 999 ? `${(p.value / 1000).toFixed(1)}K` : p.value}
          {p.unit || ''}
        </div>
      ))}
    </div>
  )
}

// ─── REACH AREA CHART ────────────────────────────────────────────────────────
interface ReachChartData { month: string; reach: number; target?: number }
export const ReachAreaChart: React.FC<{ data: ReachChartData[]; height?: number }> = ({ data, height = 180 }) => (
  <ResponsiveContainer width="100%" height={height}>
    <AreaChart data={data} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
      <defs>
        <linearGradient id="reachGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="5%" stopColor={T.violet} stopOpacity={0.4} />
          <stop offset="95%" stopColor={T.violet} stopOpacity={0} />
        </linearGradient>
        <linearGradient id="targetGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="5%" stopColor={T.emerald} stopOpacity={0.2} />
          <stop offset="95%" stopColor={T.emerald} stopOpacity={0} />
        </linearGradient>
      </defs>
      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
      <XAxis dataKey="month" tick={{ fontSize: 11, fill: T.textFaint }} axisLine={false} tickLine={false} />
      <YAxis tick={{ fontSize: 11, fill: T.textFaint }} axisLine={false} tickLine={false} tickFormatter={v => `${(v / 1000).toFixed(0)}K`} />
      <Tooltip content={<CustomTooltip />} />
      {data[0]?.target !== undefined && (
        <Area type="monotone" dataKey="target" stroke={T.emerald} strokeWidth={1.5} fill="url(#targetGrad)" strokeDasharray="4 4" dot={false} name="Target" />
      )}
      <Area type="monotone" dataKey="reach" stroke={T.violet} strokeWidth={2} fill="url(#reachGrad)" dot={false} activeDot={{ r: 5, fill: T.violet }} name="Reach" />
    </AreaChart>
  </ResponsiveContainer>
)

// ─── ENGAGEMENT BAR CHART ────────────────────────────────────────────────────
interface EngageChartData { name: string; rate: number }
export const EngagementBarChart: React.FC<{ data: EngageChartData[]; height?: number }> = ({ data, height = 180 }) => (
  <ResponsiveContainer width="100%" height={height}>
    <BarChart data={data} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
      <defs>
        <linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={T.violet} />
          <stop offset="100%" stopColor={T.violetDark} />
        </linearGradient>
      </defs>
      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
      <XAxis dataKey="name" tick={{ fontSize: 10, fill: T.textFaint }} axisLine={false} tickLine={false} />
      <YAxis tick={{ fontSize: 11, fill: T.textFaint }} axisLine={false} tickLine={false} tickFormatter={v => `${v}%`} />
      <Tooltip content={<CustomTooltip />} />
      <Bar dataKey="rate" fill="url(#barGrad)" radius={[6, 6, 2, 2]} name="Engagement" unit="%" />
    </BarChart>
  </ResponsiveContainer>
)

// ─── BUDGET PIE CHART ─────────────────────────────────────────────────────────
interface BudgetData { name: string; value: number; color: string }
export const BudgetPieChart: React.FC<{ data: BudgetData[]; height?: number }> = ({ data, height = 180 }) => (
  <ResponsiveContainer width="100%" height={height}>
    <PieChart>
      <Pie data={data} cx="50%" cy="50%" innerRadius="55%" outerRadius="80%" paddingAngle={3} dataKey="value">
        {data.map((entry, i) => <Cell key={i} fill={entry.color} />)}
      </Pie>
      <Tooltip content={<CustomTooltip />} />
    </PieChart>
  </ResponsiveContainer>
)

// ─── MINI LINE CHART (sparkline) ─────────────────────────────────────────────
interface SparklineData { value: number }
export const Sparkline: React.FC<{ data: SparklineData[]; color?: string; height?: number }> = ({
  data, color = T.violet, height = 50,
}) => (
  <ResponsiveContainer width="100%" height={height}>
    <LineChart data={data} margin={{ top: 4, right: 4, left: 4, bottom: 4 }}>
      <defs>
        <linearGradient id={`spark-${color.replace('#','')}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="5%" stopColor={color} stopOpacity={0.3} />
          <stop offset="95%" stopColor={color} stopOpacity={0} />
        </linearGradient>
      </defs>
      <Line type="monotone" dataKey="value" stroke={color} strokeWidth={2} dot={false} />
    </LineChart>
  </ResponsiveContainer>
)

// ─── BUDGET PROGRESS (linear) ─────────────────────────────────────────────────
export const BudgetProgress: React.FC<{ spent: number; total: number }> = ({ spent, total }) => {
  const pct = Math.min(Math.round((spent / total) * 100), 100)
  const color = pct > 85 ? T.rose : pct > 65 ? T.amber : T.emerald
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
        <span style={{ fontSize: 12, color: T.textFaint }}>Budget used</span>
        <span style={{ fontSize: 12, color, fontWeight: 700 }}>${spent.toLocaleString()} / ${total.toLocaleString()}</span>
      </div>
      <div style={{ background: 'rgba(255,255,255,0.06)', borderRadius: 99, height: 6 }}>
        <div style={{ width: `${pct}%`, height: '100%', background: `linear-gradient(90deg,${color},${color}aa)`, borderRadius: 99, transition: 'width 1s ease' }} />
      </div>
      <div style={{ textAlign: 'right', marginTop: 4, fontSize: 11, color: T.textFaint }}>{pct}%</div>
    </div>
  )
}
