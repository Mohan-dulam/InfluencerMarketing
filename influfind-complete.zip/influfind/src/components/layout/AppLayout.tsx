import React from 'react'
import { Outlet } from 'react-router-dom'
import { Sidebar } from './Sidebar'

export const AppLayout: React.FC = () => (
  <div style={{ minHeight: '100vh', background: '#050507', display: 'flex' }}>
    {/* Ambient orbs */}
    <div style={{ position: 'fixed', top: -200, left: 300, width: 700, height: 700, background: 'radial-gradient(circle, rgba(139,92,246,0.07) 0%, transparent 70%)', pointerEvents: 'none', zIndex: 0 }} />
    <div style={{ position: 'fixed', bottom: -150, right: 50, width: 500, height: 500, background: 'radial-gradient(circle, rgba(16,185,129,0.04) 0%, transparent 70%)', pointerEvents: 'none', zIndex: 0 }} />

    <Sidebar />

    <main style={{ marginLeft: 230, flex: 1, padding: '40px 44px', minHeight: '100vh', position: 'relative', zIndex: 1 }}>
      <div style={{ maxWidth: 1240, margin: '0 auto' }}>
        <Outlet />
      </div>
    </main>
  </div>
)
