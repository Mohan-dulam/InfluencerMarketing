import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { useCampaigns } from '@/hooks/useCampaigns'
import { useInfluencers } from '@/hooks/useInfluencers'
import { GlassCard, StatCard, Loader, Chip, ProgressBar, Avatar, Btn, T } from '@/components/ui'
import { ReachAreaChart, EngagementBarChart } from '@/components/charts'

// Static chart data — replace with real aggregated queries
const REACH_DATA = [
  { month: 'Jan', reach: 420000 }, { month: 'Feb', reach: 650000 }, { month: 'Mar', reach: 510000 },
  { month: 'Apr', reach: 890000 }, { month: 'May', reach: 760000 }, { month: 'Jun', reach: 940000 },
  { month: 'Jul', reach: 1120000 }, { month: 'Aug', reach: 980000 }, { month: 'Sep', reach: 1350000 },
  { month: 'Oct', reach: 1580000 }, { month: 'Nov', reach: 1420000 }, { month: 'Dec', reach: 1800000 },
]

const ENGAGE_DATA = [
  { name: 'Fashion', rate: 4.8 }, { name: 'Fitness', rate: 6.2 }, { name: 'Food', rate: 5.4 },
  { name: 'Tech', rate: 3.9 }, { name: 'Beauty', rate: 7.1 }, { name: 'Travel', rate: 5.0 },
]

export const Dashboard: React.FC = () => {
  const navigate = useNavigate()
  const { profile } = useAuth()
  const { campaigns, loading: campaignsLoading } = useCampaigns()
  const { influencers, loading: infLoading } = useInfluencers()
  const [ready, setReady] = useState(false)

  useEffect(() => { const t = setTimeout(() => setReady(true), 300); return () => clearTimeout(t) }, [])

  const activeCampaigns = campaigns.filter(c => c.status === 'active')
  const totalBudget = campaigns.reduce((s, c) => s + c.budget, 0)
  const totalSpent = campaigns.reduce((s, c) => s + c.spent, 0)
  const totalReach = campaigns.reduce((s, c) => s + c.actual_reach, 0)

  const statusColor: Record<string, string> = { active: T.emerald, completed: T.sky, pending: T.amber, paused: T.textFaint, cancelled: T.rose }

  if (!ready || campaignsLoading || infLoading) return <Loader text="Loading dashboard…" />

  const greeting = (() => {
    const h = new Date().getHours()
    if (h < 12) return 'Good morning'
    if (h < 17) return 'Good afternoon'
    return 'Good evening'
  })()

  return (
    <div>
      {/* Header */}
      <div className="animate-fade-up" style={{ marginBottom: 36, display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 16 }}>
        <div>
          <div style={{ color: T.textFaint, fontSize: 13, marginBottom: 6, letterSpacing: 0.5 }}>
            {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }).toUpperCase()}
          </div>
          <h1 style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 900, fontSize: 34, lineHeight: 1.1, background: 'linear-gradient(135deg,#fff 40%,#A78BFA)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            {greeting}, {profile?.full_name?.split(' ')[0] || 'there'} 👋
          </h1>
          <p style={{ color: T.textMuted, fontSize: 15, marginTop: 8 }}>
            {activeCampaigns.length} active campaign{activeCampaigns.length !== 1 ? 's' : ''} running right now.
          </p>
        </div>
        <Btn onClick={() => navigate('/campaigns')} style={{ gap: 8 }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
          New Campaign
        </Btn>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0,1fr))', gap: 16, marginBottom: 28 }}>
        <StatCard label="Total Reach" value={totalReach > 0 ? `${(totalReach / 1000000).toFixed(1)}M` : '—'} sub="Across all campaigns" icon="📡" color={T.violet} delay={0} />
        <StatCard label="Active Campaigns" value={String(activeCampaigns.length)} sub={`${campaigns.length} total`} icon="📋" color={T.emerald} delay={60} />
        <StatCard label="Influencers" value={String(influencers.length)} sub="In your database" icon="👥" color={T.amber} delay={120} />
        <StatCard label="Budget Used" value={totalBudget > 0 ? `$${(totalSpent / 1000).toFixed(1)}K` : '—'} sub={`of $${(totalBudget / 1000).toFixed(1)}K total`} icon="💎" color={T.rose} delay={180} />
      </div>

      {/* Charts */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 20, marginBottom: 20 }}>
        <GlassCard delay={200}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
            <div>
              <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 800, fontSize: 18 }}>Reach Analytics</div>
              <div style={{ color: T.textFaint, fontSize: 13, marginTop: 2 }}>Monthly reach across all campaigns</div>
            </div>
            <Chip color={T.emerald}>↑ 34% YoY</Chip>
          </div>
          <ReachAreaChart data={REACH_DATA} height={180} />
        </GlassCard>

        <GlassCard delay={250}>
          <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 800, fontSize: 18, marginBottom: 6 }}>Engagement by Niche</div>
          <div style={{ color: T.textFaint, fontSize: 13, marginBottom: 20 }}>Average engagement rate %</div>
          <EngagementBarChart data={ENGAGE_DATA} height={180} />
        </GlassCard>
      </div>

      {/* Campaigns + Influencers */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 1fr', gap: 20 }}>
        <GlassCard delay={300}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 800, fontSize: 18 }}>Recent Campaigns</div>
            <Btn variant="ghost" size="sm" onClick={() => navigate('/campaigns')}>View all →</Btn>
          </div>
          {campaigns.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '32px 0', color: T.textFaint }}>
              <div style={{ fontSize: 32, marginBottom: 10, opacity: 0.4 }}>📋</div>
              <div style={{ fontSize: 14 }}>No campaigns yet</div>
              <Btn size="sm" onClick={() => navigate('/campaigns')} style={{ marginTop: 14 }}>Create first campaign</Btn>
            </div>
          ) : (
            campaigns.slice(0, 4).map(c => (
              <div key={c.id} onClick={() => navigate('/campaigns')} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 0', borderBottom: `1px solid ${T.border}`, cursor: 'pointer' }}>
                <Avatar src={(c.influencer as any)?.avatar_url} name={c.name} size={36} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 6, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.name}</div>
                  <ProgressBar value={c.progress} color={statusColor[c.status] || T.violet} />
                </div>
                <div style={{ textAlign: 'right', flexShrink: 0 }}>
                  <div style={{ fontSize: 11, color: statusColor[c.status], fontWeight: 700 }}>{c.progress}%</div>
                  <div style={{ fontSize: 11, color: T.textFaint, marginTop: 2 }}>{c.status}</div>
                </div>
              </div>
            ))
          )}
        </GlassCard>

        <GlassCard delay={350}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 800, fontSize: 18 }}>Top Creators</div>
            <Btn variant="ghost" size="sm" onClick={() => navigate('/discover')}>Discover →</Btn>
          </div>
          {influencers.slice(0, 5).map((inf, i) => (
            <div key={inf.id} className="animate-fade-up" style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14, animationDelay: `${400 + i * 50}ms`, animationFillMode: 'both' }}>
              <Avatar src={inf.avatar_url} name={inf.name} size={40} ring={inf.accent_color} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 600, fontSize: 14, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{inf.name}</div>
                <div style={{ fontSize: 11, color: T.textFaint }}>{inf.followers_display} · {inf.engagement_rate}%</div>
              </div>
              <div style={{ flexShrink: 0 }}>
                <Chip color={T.emerald} size="sm">{inf.trend_percent}</Chip>
              </div>
            </div>
          ))}
        </GlassCard>
      </div>
    </div>
  )
}
