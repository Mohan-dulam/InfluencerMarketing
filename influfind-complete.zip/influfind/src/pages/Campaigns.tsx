import React, { useState, useRef, useEffect } from 'react'
import { useCampaigns } from '@/hooks/useCampaigns'
import { useMessages } from '@/hooks/useMessages'
import { useDeliverables } from '@/hooks/useDeliverables'
import { useInfluencers } from '@/hooks/useInfluencers'
import { GlassCard, Avatar, Btn, Loader, EmptyState, StatusPill, ProgressBar, ProgressArc, Chip, Modal, Input, Textarea, Select, T } from '@/components/ui'
import { BudgetProgress } from '@/components/charts'
import { Campaign } from '@/lib/supabase'
import { useAuth } from '@/context/AuthContext'
import toast from 'react-hot-toast'

// ── NEW CAMPAIGN MODAL ────────────────────────────────────────
const NewCampaignModal: React.FC<{ open: boolean; onClose: () => void; onCreate: (d: any) => void }> = ({ open, onClose, onCreate }) => {
  const { influencers } = useInfluencers()
  const [form, setForm] = useState({ name: '', brand: '', description: '', influencer_id: '', budget: '', deadline: '', deliverables_count: '1' })
  const [saving, setSaving] = useState(false)
  const set = (k: string) => (e: React.ChangeEvent<any>) => setForm(p => ({ ...p, [k]: e.target.value }))

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name || !form.brand) { toast.error('Name and brand required'); return }
    setSaving(true)
    await onCreate({ ...form, budget: Number(form.budget) || 0, deliverables_count: Number(form.deliverables_count) || 1 })
    setSaving(false)
    onClose()
    setForm({ name: '', brand: '', description: '', influencer_id: '', budget: '', deadline: '', deliverables_count: '1' })
  }

  return (
    <Modal open={open} onClose={onClose} maxWidth={520}>
      <div style={{ padding: '28px 28px 24px' }}>
        <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 900, fontSize: 22, marginBottom: 24 }}>New Campaign</div>
        <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <Input label="Campaign Name" placeholder="Summer Glow Collection" value={form.name} onChange={set('name')} />
          <Input label="Brand" placeholder="LumiSkin" value={form.brand} onChange={set('brand')} />
          <Textarea label="Description" placeholder="Campaign brief…" value={form.description} onChange={set('description') as any} />
          <Select label="Assign Influencer" value={form.influencer_id} onChange={set('influencer_id')}
            options={[{ value: '', label: 'None assigned' }, ...influencers.map(i => ({ value: i.id, label: `${i.name} (${i.followers_display})` }))]} />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Input label="Budget ($)" type="number" placeholder="5000" value={form.budget} onChange={set('budget')} />
            <Input label="Deadline" type="date" value={form.deadline} onChange={set('deadline')} />
          </div>
          <Input label="Deliverables Count" type="number" placeholder="3" value={form.deliverables_count} onChange={set('deliverables_count')} />
          <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
            <Btn type="submit" loading={saving} fullWidth>Create Campaign</Btn>
            <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
          </div>
        </form>
      </div>
    </Modal>
  )
}

// ── CHAT PANEL ────────────────────────────────────────────────
const ChatPanel: React.FC<{ campaignId: string; influencer: any }> = ({ campaignId, influencer }) => {
  const { messages, sendMessage } = useMessages(campaignId)
  const { user, profile } = useAuth()
  const [msg, setMsg] = useState('')
  const chatRef = useRef<HTMLDivElement>(null)

  useEffect(() => { chatRef.current?.scrollTo({ top: 9999, behavior: 'smooth' }) }, [messages])

  const send = async () => {
    if (!msg.trim()) return
    const text = msg
    setMsg('')
    await sendMessage(text)
  }

  return (
    <GlassCard style={{ padding: 0, overflow: 'hidden' }}>
      <div style={{ padding: '14px 20px', borderBottom: `1px solid ${T.border}`, fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 700, fontSize: 15, display: 'flex', alignItems: 'center', gap: 10 }}>
        <Avatar src={influencer?.avatar_url} name={influencer?.name || 'Influencer'} size={28} />
        Messages · {influencer?.name || 'Campaign Chat'}
      </div>
      <div ref={chatRef} style={{ height: 220, overflowY: 'auto', padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {messages.length === 0 ? (
          <div style={{ textAlign: 'center', color: T.textFaint, padding: '40px 0', fontSize: 13 }}>No messages yet. Start the conversation!</div>
        ) : messages.map(m => {
          const isMe = m.sender_id === user?.id
          return (
            <div key={m.id} style={{ display: 'flex', gap: 8, flexDirection: isMe ? 'row-reverse' : 'row', animation: 'fadeUp 0.2s ease' }}>
              <Avatar src={isMe ? profile?.avatar_url : influencer?.avatar_url} name={m.sender_name} size={28} />
              <div style={{ maxWidth: '72%', background: isMe ? 'linear-gradient(135deg,#8B5CF6,#6D28D9)' : 'rgba(255,255,255,0.07)', borderRadius: isMe ? '16px 16px 4px 16px' : '16px 16px 16px 4px', padding: '10px 14px', border: isMe ? 'none' : `1px solid ${T.border}` }}>
                <div style={{ fontSize: 13, color: '#fff', lineHeight: 1.5 }}>{m.content}</div>
                <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', marginTop: 4 }}>{new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
              </div>
            </div>
          )
        })}
      </div>
      <div style={{ padding: '12px 16px', borderTop: `1px solid ${T.border}`, display: 'flex', gap: 10 }}>
        <input value={msg} onChange={e => setMsg(e.target.value)} onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()} placeholder="Type a message…"
          style={{ flex: 1, background: 'rgba(255,255,255,0.05)', border: `1px solid ${T.border}`, borderRadius: 10, color: T.text, padding: '9px 14px', fontSize: 13, outline: 'none', fontFamily: "'Satoshi',sans-serif" }} />
        <Btn size="sm" onClick={send}>Send ↑</Btn>
      </div>
    </GlassCard>
  )
}

// ── DELIVERABLES PANEL ────────────────────────────────────────
const DeliverablesPanel: React.FC<{ campaignId: string }> = ({ campaignId }) => {
  const { deliverables, uploading, upload } = useDeliverables(campaignId)
  const inputRef = useRef<HTMLInputElement>(null)

  return (
    <GlassCard>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 700, fontSize: 15 }}>Deliverables</div>
        <Btn size="sm" variant="ghost" onClick={() => inputRef.current?.click()} loading={uploading}>
          ⬆ Upload
        </Btn>
        <input ref={inputRef} type="file" style={{ display: 'none' }} onChange={e => e.target.files?.[0] && upload(e.target.files[0])} accept="image/*,video/*,.pdf,.zip" />
      </div>
      {deliverables.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '24px 0', color: T.textFaint, fontSize: 13 }}>No deliverables yet</div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {deliverables.map(d => (
            <div key={d.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', background: 'rgba(255,255,255,0.04)', borderRadius: 10, border: `1px solid ${T.border}` }}>
              <div style={{ fontSize: 20 }}>{d.file_type?.startsWith('image') ? '🖼' : d.file_type?.startsWith('video') ? '🎥' : '📄'}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.file_name}</div>
                <div style={{ fontSize: 11, color: T.textFaint }}>{d.file_size ? `${(d.file_size / 1024 / 1024).toFixed(1)} MB` : ''} · {new Date(d.created_at).toLocaleDateString()}</div>
              </div>
              <Chip color={d.status === 'approved' ? T.emerald : d.status === 'rejected' ? '#EF4444' : T.amber} size="sm">{d.status}</Chip>
              <a href={d.file_url} target="_blank" rel="noreferrer" style={{ color: T.textFaint, fontSize: 16, textDecoration: 'none' }}>↗</a>
            </div>
          ))}
        </div>
      )}
    </GlassCard>
  )
}

// ── MAIN PAGE ─────────────────────────────────────────────────
export const Campaigns: React.FC = () => {
  const { campaigns, loading, createCampaign, markComplete } = useCampaigns()
  const [selected, setSelected] = useState<Campaign | null>(null)
  const [showNew, setShowNew] = useState(false)

  useEffect(() => {
    if (campaigns.length > 0 && !selected) setSelected(campaigns[0])
  }, [campaigns])

  const selectedInfluencer = (selected as any)?.influencer

  if (loading) return <Loader text="Loading campaigns…" />

  return (
    <div>
      <div className="animate-fade-up" style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 28 }}>
        <div>
          <h1 style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 900, fontSize: 32, background: 'linear-gradient(135deg,#fff 40%,#A78BFA)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Campaigns</h1>
          <p style={{ color: T.textMuted, fontSize: 15, marginTop: 6 }}>{campaigns.length} total · {campaigns.filter(c => c.status === 'active').length} live</p>
        </div>
        <Btn onClick={() => setShowNew(true)}>+ New Campaign</Btn>
      </div>

      {campaigns.length === 0 ? (
        <EmptyState icon="📋" title="No campaigns yet" description="Create your first influencer campaign to get started." action={<Btn onClick={() => setShowNew(true)}>Create Campaign</Btn>} />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '340px 1fr', gap: 20 }}>
          {/* List */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {campaigns.map((c, i) => (
              <div key={c.id} onClick={() => setSelected(c)} className="animate-fade-up"
                style={{ background: selected?.id === c.id ? 'rgba(139,92,246,0.12)' : 'rgba(255,255,255,0.03)', border: selected?.id === c.id ? '1px solid rgba(139,92,246,0.35)' : `1px solid ${T.border}`, borderRadius: 16, padding: '16px 18px', cursor: 'pointer', transition: 'all 0.2s', animationDelay: `${i * 50}ms`, animationFillMode: 'both' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                  <Avatar src={(c as any).influencer?.avatar_url} name={c.name} size={36} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 700, fontSize: 14, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.name}</div>
                    <div style={{ fontSize: 12, color: T.textFaint }}>{c.brand}</div>
                  </div>
                  <StatusPill status={c.status} />
                </div>
                <ProgressBar value={c.progress} color={c.status === 'completed' ? T.emerald : T.violet} />
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8 }}>
                  <span style={{ fontSize: 11, color: T.textFaint }}>{(c as any).influencer?.name || 'No influencer'}</span>
                  <span style={{ fontSize: 11, color: selected?.id === c.id ? T.violetLight : T.textFaint, fontWeight: 700 }}>{c.progress}%</span>
                </div>
              </div>
            ))}
          </div>

          {/* Detail */}
          {selected && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <GlassCard>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 20 }}>
                  <Avatar src={selectedInfluencer?.avatar_url} name={selected.name} size={52} ring={T.violet} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 900, fontSize: 20 }}>{selected.name}</div>
                    <div style={{ fontSize: 13, color: T.textFaint }}>with {selectedInfluencer?.name || 'TBD'} · Due {selected.deadline ? new Date(selected.deadline).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : 'No deadline'}</div>
                  </div>
                  <StatusPill status={selected.status} />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 20 }}>
                  {[['Expected Reach', selected.expected_reach > 0 ? `${(selected.expected_reach / 1000).toFixed(0)}K` : '—', T.violet], ['Actual Reach', selected.actual_reach > 0 ? `${(selected.actual_reach / 1000).toFixed(0)}K` : '—', T.emerald], ['Deliverables', `${selected.deliverables_submitted}/${selected.deliverables_count}`, T.amber]].map(([l, v, c]) => (
                    <div key={l} style={{ background: 'rgba(255,255,255,0.04)', borderRadius: 12, padding: 14, border: `1px solid ${T.border}` }}>
                      <div style={{ fontSize: 11, color: T.textFaint, marginBottom: 6 }}>{l}</div>
                      <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 800, fontSize: 18, color: c as string }}>{v}</div>
                    </div>
                  ))}
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: 20, marginBottom: 20 }}>
                  <div style={{ position: 'relative', flexShrink: 0 }}>
                    <ProgressArc value={selected.progress} size={60} color={selected.status === 'completed' ? T.emerald : T.violet} />
                    <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 800 }}>{selected.progress}%</div>
                  </div>
                  <div style={{ flex: 1 }}>
                    <BudgetProgress spent={selected.spent} total={selected.budget} />
                  </div>
                </div>

                <div style={{ display: 'flex', gap: 10 }}>
                  {selected.status !== 'completed' && (
                    <Btn variant="success" size="sm" onClick={() => markComplete(selected.id)}>✓ Mark Complete</Btn>
                  )}
                  {selected.notes && <div style={{ fontSize: 13, color: T.textMuted, padding: '8px 12px', background: 'rgba(255,255,255,0.04)', borderRadius: 8, flex: 1 }}>{selected.notes}</div>}
                </div>
              </GlassCard>

              <ChatPanel campaignId={selected.id} influencer={selectedInfluencer} />
              <DeliverablesPanel campaignId={selected.id} />
            </div>
          )}
        </div>
      )}

      <NewCampaignModal open={showNew} onClose={() => setShowNew(false)} onCreate={createCampaign} />
    </div>
  )
}
