import React, { useState } from 'react'
import { useInfluencers } from '@/hooks/useInfluencers'
import { GlassCard, Avatar, Chip, Btn, Loader, EmptyState, Modal, T, ProgressBar } from '@/components/ui'
import { Influencer } from '@/lib/supabase'
import toast from 'react-hot-toast'

const NICHES = ['All', 'Fashion & Lifestyle', 'Fitness & Health', 'Food & Travel', 'Tech & Gaming', 'Beauty & Skincare', 'Travel & Adventure']
const PLATFORMS = ['All', 'Instagram', 'YouTube', 'TikTok', 'Twitter', 'LinkedIn']
const SORT_OPTIONS = [
  { value: 'followers', label: '↓ Followers' },
  { value: 'engagement_rate', label: '↓ Engagement' },
  { value: 'rating', label: '↓ Rating' },
  { value: 'fee_per_post', label: '↓ Fee (low)' },
]

export const Discover: React.FC = () => {
  const { influencers, loading, filters, setFilters } = useInfluencers()
  const [selected, setSelected] = useState<Influencer | null>(null)

  const inputStyle: React.CSSProperties = {
    background: 'rgba(255,255,255,0.05)', border: `1px solid ${T.border}`, borderRadius: 12,
    color: T.text, padding: '10px 14px', fontSize: 14, outline: 'none', fontFamily: "'Satoshi',sans-serif",
  }

  return (
    <div>
      {/* Header */}
      <div className="animate-fade-up" style={{ marginBottom: 28 }}>
        <h1 style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 900, fontSize: 32, background: 'linear-gradient(135deg,#fff 40%,#A78BFA)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
          Discover Creators
        </h1>
        <p style={{ color: T.textMuted, fontSize: 15, marginTop: 6 }}>
          {loading ? 'Searching…' : `${influencers.length} creators match your criteria`}
        </p>
      </div>

      {/* Filters */}
      <GlassCard style={{ marginBottom: 24, padding: '16px 20px' }}>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
          <div style={{ flex: 1, minWidth: 220, position: 'relative' }}>
            <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: T.textFaint }}>🔍</span>
            <input
              value={filters.search}
              onChange={e => setFilters(f => ({ ...f, search: e.target.value }))}
              placeholder="Search by name or handle…"
              style={{ ...inputStyle, width: '100%', paddingLeft: 34 }}
            />
          </div>
          <select value={filters.niche} onChange={e => setFilters(f => ({ ...f, niche: e.target.value }))} style={inputStyle}>
            {NICHES.map(n => <option key={n} value={n} style={{ background: '#1a1033' }}>{n}</option>)}
          </select>
          <select value={filters.platform} onChange={e => setFilters(f => ({ ...f, platform: e.target.value }))} style={inputStyle}>
            {PLATFORMS.map(p => <option key={p} value={p} style={{ background: '#1a1033' }}>{p}</option>)}
          </select>
          <select value={filters.sortBy} onChange={e => setFilters(f => ({ ...f, sortBy: e.target.value as any }))} style={inputStyle}>
            {SORT_OPTIONS.map(o => <option key={o.value} value={o.value} style={{ background: '#1a1033' }}>{o.label}</option>)}
          </select>
        </div>
      </GlassCard>

      {loading ? (
        <Loader text="Fetching creators from database…" />
      ) : influencers.length === 0 ? (
        <EmptyState icon="🔍" title="No creators found" description="Try adjusting your filters." action={<Btn onClick={() => setFilters(f => ({ ...f, search: '', niche: 'All', platform: 'All' }))} variant="ghost">Clear Filters</Btn>} />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0,1fr))', gap: 20 }}>
          {influencers.map((inf, i) => (
            <InfluCard key={inf.id} inf={inf} onSelect={setSelected} delay={i * 50} />
          ))}
        </div>
      )}

      <Modal open={!!selected} onClose={() => setSelected(null)} maxWidth={580}>
        {selected && <InfluModal inf={selected} onClose={() => setSelected(null)} />}
      </Modal>
    </div>
  )
}

const InfluCard: React.FC<{ inf: Influencer; onSelect: (i: Influencer) => void; delay: number }> = ({ inf, onSelect, delay }) => {
  const [hov, setHov] = useState(false)
  return (
    <div
      className="animate-fade-up"
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        borderRadius: 20, overflow: 'hidden',
        background: 'rgba(255,255,255,0.04)',
        border: hov ? `1px solid ${inf.accent_color}55` : `1px solid ${T.border}`,
        transition: 'all 0.25s cubic-bezier(.22,1,.36,1)',
        animationDelay: `${delay}ms`, animationFillMode: 'both',
        cursor: 'pointer',
        transform: hov ? 'translateY(-4px)' : 'none',
        boxShadow: hov ? `0 20px 60px rgba(0,0,0,0.4)` : 'none',
      }}
      onClick={() => onSelect(inf)}
    >
      {/* Cover */}
      <div style={{ position: 'relative', height: 150, overflow: 'hidden' }}>
        <img src={inf.cover_url || `https://picsum.photos/seed/${inf.id}/600/300`} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', transform: hov ? 'scale(1.06)' : 'scale(1)', transition: 'transform 0.5s cubic-bezier(.22,1,.36,1)' }} />
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, rgba(5,5,7,0.92) 0%, rgba(5,5,7,0.15) 60%, transparent 100%)' }} />
        <div style={{ position: 'absolute', top: 12, right: 12 }}>
          <Chip color={inf.platform === 'Instagram' ? '#EC4899' : inf.platform === 'YouTube' ? '#FF0000' : T.sky} size="sm">{inf.platform}</Chip>
        </div>
        {inf.verified && <div style={{ position: 'absolute', top: 12, left: 12, background: T.violet, color: '#fff', borderRadius: 8, fontSize: 11, padding: '3px 9px', fontWeight: 700 }}>✓ Verified</div>}
        <div style={{ position: 'absolute', bottom: 12, left: 14, display: 'flex', alignItems: 'center', gap: 10 }}>
          <Avatar src={inf.avatar_url} name={inf.name} size={44} ring={inf.accent_color} />
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, color: '#fff' }}>{inf.name}</div>
            <div style={{ color: 'rgba(255,255,255,0.55)', fontSize: 12 }}>{inf.handle}</div>
          </div>
        </div>
      </div>

      {/* Body */}
      <div style={{ padding: '14px 16px' }}>
        <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap', marginBottom: 12, alignItems: 'center' }}>
          {(inf.tags || []).slice(0, 3).map(t => (
            <span key={t} style={{ background: 'rgba(255,255,255,0.06)', color: T.textMuted, fontSize: 11, padding: '3px 7px', borderRadius: 6 }}>#{t}</span>
          ))}
          {inf.trend_percent && <span style={{ marginLeft: 'auto' }}><Chip color={T.emerald} size="sm">{inf.trend_percent}</Chip></span>}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginBottom: 14 }}>
          {[['Followers', inf.followers_display, T.violetLight], ['Engage', `${inf.engagement_rate}%`, T.emerald], ['Views', inf.avg_views_display, T.sky]].map(([l, v, c]) => (
            <div key={l} style={{ background: 'rgba(255,255,255,0.04)', borderRadius: 10, padding: '8px', textAlign: 'center', border: `1px solid ${T.border}` }}>
              <div style={{ fontSize: 10, color: T.textFaint, marginBottom: 3 }}>{l}</div>
              <div style={{ fontWeight: 800, fontSize: 13, color: c as string }}>{v}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontSize: 10, color: T.textFaint }}>Fee per post</div>
            <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 900, fontSize: 17, color: '#fff' }}>${inf.fee_per_post.toLocaleString()}</div>
          </div>
          <Btn size="sm" onClick={e => { e.stopPropagation(); toast.success(`Invite sent to ${inf.name}!`) }}>+ Invite</Btn>
        </div>
      </div>
    </div>
  )
}

const InfluModal: React.FC<{ inf: Influencer; onClose: () => void }> = ({ inf, onClose }) => (
  <div>
    <div style={{ position: 'relative', height: 220 }}>
      <img src={inf.cover_url || `https://picsum.photos/seed/${inf.id}/600/300`} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, rgba(20,18,35,0.97) 0%, transparent 50%)' }} />
      <button onClick={onClose} style={{ position: 'absolute', top: 16, right: 16, background: 'rgba(0,0,0,0.5)', border: `1px solid ${T.border}`, color: '#fff', width: 34, height: 34, borderRadius: '50%', cursor: 'pointer', fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>×</button>
      <div style={{ position: 'absolute', bottom: 20, left: 24, display: 'flex', alignItems: 'center', gap: 14 }}>
        <Avatar src={inf.avatar_url} name={inf.name} size={64} ring={inf.accent_color} />
        <div>
          <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 900, fontSize: 22, color: '#fff' }}>{inf.name}</div>
          <div style={{ color: 'rgba(255,255,255,0.55)', marginTop: 2 }}>{inf.handle} · {inf.location}</div>
        </div>
      </div>
    </div>
    <div style={{ padding: '24px 28px' }}>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16, alignItems: 'center' }}>
        <Chip color={T.violet}>{inf.niche}</Chip>
        <Chip color={inf.platform === 'Instagram' ? '#EC4899' : '#FF0000'}>{inf.platform}</Chip>
        {inf.verified && <Chip color={T.emerald}>✓ Verified</Chip>}
        <span style={{ marginLeft: 'auto', fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 900, fontSize: 22, color: T.violetLight }}>
          ${inf.fee_per_post.toLocaleString()}<span style={{ fontSize: 13, color: T.textFaint, fontWeight: 400 }}>/post</span>
        </span>
      </div>

      {inf.bio && <p style={{ color: T.textMuted, fontSize: 14, lineHeight: 1.7, marginBottom: 20, padding: 14, background: 'rgba(255,255,255,0.03)', borderRadius: 12, border: `1px solid ${T.border}` }}>{inf.bio}</p>}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 10, marginBottom: 20 }}>
        {[['Followers', inf.followers_display, T.violetLight], ['Engagement', `${inf.engagement_rate}%`, T.emerald], ['Avg Views', inf.avg_views_display, T.sky], ['Rating', `★ ${inf.rating}`, T.amber]].map(([l, v, c]) => (
          <div key={l} style={{ background: 'rgba(255,255,255,0.05)', borderRadius: 12, padding: 14, textAlign: 'center', border: `1px solid ${T.border}` }}>
            <div style={{ fontSize: 11, color: T.textFaint, marginBottom: 6 }}>{l}</div>
            <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 900, fontSize: 18, color: c as string }}>{v}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: 10 }}>
        <Btn fullWidth onClick={() => { toast.success(`Collaboration request sent to ${inf.name}!`); onClose() }}>
          Send Collaboration Request
        </Btn>
        <Btn variant="ghost" onClick={onClose}>Close</Btn>
      </div>
    </div>
  </div>
)
