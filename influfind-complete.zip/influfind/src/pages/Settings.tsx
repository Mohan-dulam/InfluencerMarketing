import React, { useState, useRef } from 'react'
import { useAuth } from '@/context/AuthContext'
import { createCheckoutSession, openCustomerPortal, PLANS, PlanKey } from '@/lib/stripe'
import { GlassCard, Btn, Input, Textarea, Toggle, Avatar, Chip, PageHeader, T } from '@/components/ui'
import toast from 'react-hot-toast'

const TABS = ['profile', 'subscription', 'payment', 'notifications', 'preferences'] as const
type Tab = typeof TABS[number]

export const Settings: React.FC = () => {
  const { user, profile, updateProfile, uploadAvatar } = useAuth()
  const [tab, setTab] = useState<Tab>('profile')
  const [saving, setSaving] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [checkoutLoading, setCheckoutLoading] = useState<string | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  // Profile form
  const [form, setForm] = useState({
    full_name: profile?.full_name || '',
    brand_name: profile?.brand_name || '',
    website: profile?.website || '',
    bio: profile?.bio || '',
  })

  // Prefs
  const [prefs, setPrefs] = useState({ darkMode: true, emailNotifs: true, pushNotifs: true, matchAlerts: true, campaignUpdates: true, weeklyReport: false })

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm(p => ({ ...p, [k]: e.target.value }))

  const saveProfile = async () => {
    setSaving(true)
    try { await updateProfile(form) }
    catch (err: any) { toast.error(err.message) }
    finally { setSaving(false) }
  }

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploading(true)
    try { await uploadAvatar(file); toast.success('Avatar updated!') }
    catch (err: any) { toast.error(err.message) }
    finally { setUploading(false) }
  }

  const handleSubscribe = async (planKey: PlanKey) => {
    setCheckoutLoading(planKey)
    try { await createCheckoutSession(planKey) }
    catch (err: any) { toast.error(err.message || 'Billing error. Check Stripe config.') }
    finally { setCheckoutLoading(null) }
  }

  const inp: React.CSSProperties = { background: 'rgba(255,255,255,0.05)', border: `1px solid ${T.border}`, borderRadius: 12, color: T.text, padding: '10px 14px', fontSize: 14, outline: 'none', fontFamily: "'Satoshi',sans-serif", width: '100%', marginBottom: 16 }

  return (
    <div>
      <PageHeader title="Settings" subtitle="Manage your account, billing, and preferences." />

      <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr', gap: 24 }}>
        {/* Sidebar nav */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
          {TABS.map(t => (
            <div key={t} onClick={() => setTab(t)}
              style={{ padding: '11px 16px', borderRadius: 12, cursor: 'pointer', fontWeight: 600, fontSize: 14, background: tab === t ? 'rgba(139,92,246,0.15)' : 'transparent', color: tab === t ? T.violetLight : T.textFaint, border: tab === t ? '1px solid rgba(139,92,246,0.25)' : '1px solid transparent', transition: 'all 0.2s', textTransform: 'capitalize' }}>
              {t}
            </div>
          ))}
        </div>

        {/* Panel */}
        <div>
          {/* ── PROFILE ── */}
          {tab === 'profile' && (
            <GlassCard>
              <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 800, fontSize: 20, marginBottom: 24 }}>Profile Settings</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 18, marginBottom: 28 }}>
                <div style={{ position: 'relative' }}>
                  <Avatar src={profile?.avatar_url} name={profile?.full_name || 'User'} size={76} ring={T.violet + '80'} />
                  <div onClick={() => fileRef.current?.click()} style={{ position: 'absolute', bottom: 0, right: 0, width: 26, height: 26, background: T.violet, borderRadius: '50%', border: '2px solid #050507', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, cursor: 'pointer' }}>
                    {uploading ? '…' : '✎'}
                  </div>
                  <input ref={fileRef} type="file" style={{ display: 'none' }} accept="image/*" onChange={handleAvatarUpload} />
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 18, marginBottom: 6 }}>{profile?.full_name || 'Your Name'}</div>
                  <div style={{ color: T.textFaint, fontSize: 13, marginBottom: 8 }}>{user?.email}</div>
                  <Chip color={T.violet}>⬡ {(profile?.plan || 'Free').charAt(0).toUpperCase() + (profile?.plan || 'free').slice(1)} Plan</Chip>
                </div>
              </div>

              {[['Full Name', 'full_name', 'Aarav Mehta', 'text'], ['Brand Name', 'brand_name', 'LumiSkin Co.', 'text'], ['Website', 'website', 'lumiskin.com', 'url']].map(([l, k, ph, t]) => (
                <div key={k}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: T.textFaint, marginBottom: 8, letterSpacing: 1 }}>{l.toUpperCase()}</div>
                  <input type={t} value={(form as any)[k]} onChange={set(k)} placeholder={ph} style={inp} />
                </div>
              ))}
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: T.textFaint, marginBottom: 8, letterSpacing: 1 }}>BIO</div>
                <textarea value={form.bio} onChange={set('bio') as any} placeholder="Tell influencers about your brand…" style={{ ...inp, minHeight: 80, resize: 'vertical' }} />
              </div>

              <Btn onClick={saveProfile} loading={saving}>Save Changes</Btn>
            </GlassCard>
          )}

          {/* ── SUBSCRIPTION ── */}
          {tab === 'subscription' && (
            <div>
              <GlassCard style={{ marginBottom: 20 }}>
                <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 800, fontSize: 20, marginBottom: 20 }}>Current Plan</div>
                <div style={{ background: 'linear-gradient(135deg,rgba(139,92,246,0.3),rgba(109,40,217,0.4))', borderRadius: 16, padding: '26px', border: '1px solid rgba(139,92,246,0.4)', marginBottom: 20, position: 'relative', overflow: 'hidden' }}>
                  <div style={{ position: 'absolute', top: -30, right: -30, width: 140, height: 140, background: 'rgba(139,92,246,0.15)', borderRadius: '50%' }} />
                  <div style={{ fontSize: 12, color: T.violetLight, marginBottom: 8, letterSpacing: 1 }}>ACTIVE PLAN</div>
                  <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontSize: 36, fontWeight: 900 }}>
                    {(profile?.plan || 'Free').charAt(0).toUpperCase() + (profile?.plan || 'free').slice(1)} ⬡
                  </div>
                  <div style={{ color: T.textMuted, marginTop: 8 }}>
                    {profile?.plan === 'free' ? 'Free plan — upgrade to unlock all features' : `Active subscription · ${profile?.subscription_status}`}
                  </div>
                  {profile?.plan !== 'free' && (
                    <Btn variant="ghost" size="sm" style={{ marginTop: 14 }} onClick={openCustomerPortal}>Manage Billing ↗</Btn>
                  )}
                </div>
              </GlassCard>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,minmax(0,1fr))', gap: 16 }}>
                {(Object.entries(PLANS) as [PlanKey, typeof PLANS[PlanKey]][]).map(([key, plan]) => {
                  const isCurrent = profile?.plan === key
                  return (
                    <div key={key} style={{ background: isCurrent ? 'rgba(139,92,246,0.12)' : 'rgba(255,255,255,0.03)', border: isCurrent ? '1.5px solid rgba(139,92,246,0.4)' : `1px solid ${T.border}`, borderRadius: 18, padding: '22px', position: 'relative' }}>
                      {(plan as any).popular && !isCurrent && (
                        <div style={{ position: 'absolute', top: -11, left: '50%', transform: 'translateX(-50%)', background: 'linear-gradient(135deg,#8B5CF6,#6D28D9)', color: '#fff', borderRadius: 99, fontSize: 11, padding: '3px 14px', fontWeight: 700, whiteSpace: 'nowrap' }}>
                          Most Popular
                        </div>
                      )}
                      {isCurrent && (
                        <div style={{ position: 'absolute', top: -11, left: '50%', transform: 'translateX(-50%)', background: T.emerald, color: '#fff', borderRadius: 99, fontSize: 11, padding: '3px 14px', fontWeight: 700, whiteSpace: 'nowrap' }}>
                          ✓ Current Plan
                        </div>
                      )}
                      <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 900, fontSize: 20, marginBottom: 6 }}>{plan.name}</div>
                      <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontSize: 30, fontWeight: 900, color: T.violetLight, marginBottom: 16 }}>
                        {plan.price}<span style={{ fontSize: 14, color: T.textFaint, fontWeight: 400 }}>/mo</span>
                      </div>
                      <div style={{ marginBottom: 20 }}>
                        {plan.features.map(f => <div key={f} style={{ fontSize: 13, color: T.textMuted, marginBottom: 7 }}>✓ {f}</div>)}
                      </div>
                      <Btn
                        variant={isCurrent ? 'ghost' : 'primary'}
                        size="sm"
                        fullWidth
                        disabled={isCurrent}
                        loading={checkoutLoading === key}
                        onClick={() => !isCurrent && handleSubscribe(key)}
                      >
                        {isCurrent ? 'Current Plan' : `Upgrade to ${plan.name}`}
                      </Btn>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {/* ── PAYMENT ── */}
          {tab === 'payment' && (
            <GlassCard>
              <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 800, fontSize: 20, marginBottom: 22 }}>Payment Method</div>
              {/* Credit card visual */}
              <div style={{ background: 'linear-gradient(135deg,#1a1033,#0d0820)', borderRadius: 18, padding: '26px', border: '1px solid rgba(139,92,246,0.3)', maxWidth: 380, marginBottom: 24, position: 'relative', overflow: 'hidden' }}>
                <div style={{ position: 'absolute', top: 0, right: 0, width: 200, height: 200, background: 'radial-gradient(circle, rgba(139,92,246,0.15) 0%, transparent 70%)' }} />
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 34 }}>
                  <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 900, fontSize: 20, letterSpacing: 1 }}>InfluFind</div>
                  <div style={{ fontSize: 26, color: T.violetLight }}>⬡</div>
                </div>
                <div style={{ fontFamily: 'monospace', fontSize: 18, letterSpacing: 4, marginBottom: 26, color: 'rgba(255,255,255,0.8)' }}>•••• •••• •••• 4242</div>
                <div style={{ display: 'flex', gap: 28, fontSize: 13 }}>
                  <div><div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 10, letterSpacing: 1, marginBottom: 4 }}>CARD HOLDER</div><div style={{ fontWeight: 600 }}>{profile?.full_name || 'Your Name'}</div></div>
                  <div><div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 10, letterSpacing: 1, marginBottom: 4 }}>EXPIRES</div><div style={{ fontWeight: 600 }}>09/27</div></div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 10, marginBottom: 28 }}>
                <Btn variant="ghost" size="sm" onClick={openCustomerPortal}>+ Add / Change Card ↗</Btn>
              </div>
              <div style={{ borderTop: `1px solid ${T.border}`, paddingTop: 22 }}>
                <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 700, fontSize: 16, marginBottom: 16 }}>Billing History</div>
                <div style={{ color: T.textFaint, fontSize: 13, padding: '16px 0' }}>
                  Billing history is managed through Stripe. <button onClick={openCustomerPortal} style={{ background: 'none', border: 'none', color: T.violetLight, cursor: 'pointer', fontSize: 13, textDecoration: 'underline', fontFamily: "'Satoshi',sans-serif" }}>Open customer portal ↗</button>
                </div>
              </div>
            </GlassCard>
          )}

          {/* ── NOTIFICATIONS ── */}
          {tab === 'notifications' && (
            <GlassCard>
              <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 800, fontSize: 20, marginBottom: 22 }}>Notification Preferences</div>
              <Toggle value={prefs.emailNotifs} onChange={v => setPrefs(p => ({ ...p, emailNotifs: v }))} label="Email Notifications" description="Receive all updates via email" />
              <Toggle value={prefs.pushNotifs} onChange={v => setPrefs(p => ({ ...p, pushNotifs: v }))} label="Push Notifications" description="Browser push alerts in real time" />
              <Toggle value={prefs.matchAlerts} onChange={v => setPrefs(p => ({ ...p, matchAlerts: v }))} label="Influencer Match Alerts" description="When a creator matches your campaign criteria" />
              <Toggle value={prefs.campaignUpdates} onChange={v => setPrefs(p => ({ ...p, campaignUpdates: v }))} label="Campaign Updates" description="Progress and milestone notifications" />
              <Toggle value={prefs.weeklyReport} onChange={v => setPrefs(p => ({ ...p, weeklyReport: v }))} label="Weekly Reports" description="Summary digest every Monday morning" />
              <div style={{ marginTop: 20 }}>
                <Btn onClick={() => toast.success('Preferences saved!')}>Save Preferences</Btn>
              </div>
            </GlassCard>
          )}

          {/* ── PREFERENCES ── */}
          {tab === 'preferences' && (
            <GlassCard>
              <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 800, fontSize: 20, marginBottom: 22 }}>Preferences</div>
              <Toggle value={prefs.darkMode} onChange={v => setPrefs(p => ({ ...p, darkMode: v }))} label="Dark Mode" description="Cinematic dark UI — the way InfluFind was designed" />
              <div style={{ marginTop: 20 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: T.textFaint, marginBottom: 10, letterSpacing: 1 }}>DEFAULT CURRENCY</div>
                <select style={{ background: 'rgba(15,14,23,0.9)', border: `1px solid ${T.border}`, borderRadius: 12, color: T.text, padding: '10px 14px', fontSize: 14, width: '100%', outline: 'none', fontFamily: "'Satoshi',sans-serif", marginBottom: 16 }}>
                  <option style={{ background: '#1a1033' }}>USD – US Dollar</option>
                  <option style={{ background: '#1a1033' }}>INR – Indian Rupee</option>
                  <option style={{ background: '#1a1033' }}>EUR – Euro</option>
                  <option style={{ background: '#1a1033' }}>GBP – British Pound</option>
                </select>
                <div style={{ fontSize: 11, fontWeight: 700, color: T.textFaint, marginBottom: 10, letterSpacing: 1 }}>TIME ZONE</div>
                <select style={{ background: 'rgba(15,14,23,0.9)', border: `1px solid ${T.border}`, borderRadius: 12, color: T.text, padding: '10px 14px', fontSize: 14, width: '100%', outline: 'none', fontFamily: "'Satoshi',sans-serif" }}>
                  <option style={{ background: '#1a1033' }}>IST – India Standard Time (UTC+5:30)</option>
                  <option style={{ background: '#1a1033' }}>PST – Pacific Standard Time (UTC-8)</option>
                  <option style={{ background: '#1a1033' }}>EST – Eastern Standard Time (UTC-5)</option>
                  <option style={{ background: '#1a1033' }}>GMT – Greenwich Mean Time (UTC+0)</option>
                </select>
              </div>
              <div style={{ marginTop: 20 }}>
                <Btn onClick={() => toast.success('Preferences saved!')}>Save Preferences</Btn>
              </div>
              <div style={{ marginTop: 28, paddingTop: 20, borderTop: `1px solid ${T.border}` }}>
                <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 700, fontSize: 16, color: '#EF4444', marginBottom: 8 }}>Danger Zone</div>
                <div style={{ color: T.textFaint, fontSize: 13, marginBottom: 14 }}>Permanently delete your account and all associated data.</div>
                <Btn variant="danger" size="sm" onClick={() => toast.error('Please contact support to delete your account.')}>Delete Account</Btn>
              </div>
            </GlassCard>
          )}
        </div>
      </div>
    </div>
  )
}
