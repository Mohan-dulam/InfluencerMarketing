import React, { useState } from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { Btn, Input, T } from '@/components/ui'
import toast from 'react-hot-toast'

export const Auth: React.FC = () => {
  const { user, signIn, signUp, loading } = useAuth()
  const [mode, setMode] = useState<'login' | 'signup'>('login')
  const [submitting, setSubmitting] = useState(false)
  const [form, setForm] = useState({ email: '', password: '', fullName: '', brandName: '' })
  const [errors, setErrors] = useState<Record<string, string>>({})

  if (!loading && user) return <Navigate to="/" replace />

  const validate = () => {
    const e: Record<string, string> = {}
    if (!form.email) e.email = 'Email is required'
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = 'Invalid email'
    if (!form.password) e.password = 'Password is required'
    else if (form.password.length < 6) e.password = 'Min 6 characters'
    if (mode === 'signup' && !form.fullName) e.fullName = 'Full name is required'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!validate()) return
    setSubmitting(true)
    try {
      if (mode === 'login') await signIn(form.email, form.password)
      else await signUp(form.email, form.password, form.fullName)
    } catch (err: any) {
      toast.error(err.message || 'Authentication failed')
    } finally {
      setSubmitting(false)
    }
  }

  const set = (key: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm(prev => ({ ...prev, [key]: e.target.value }))
    if (errors[key]) setErrors(prev => ({ ...prev, [key]: '' }))
  }

  return (
    <div style={{ minHeight: '100vh', background: '#050507', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20, position: 'relative', overflow: 'hidden' }}>
      {/* Background orbs */}
      <div style={{ position: 'fixed', top: -200, left: '20%', width: 600, height: 600, background: 'radial-gradient(circle, rgba(139,92,246,0.12) 0%, transparent 70%)', pointerEvents: 'none' }} />
      <div style={{ position: 'fixed', bottom: -200, right: '10%', width: 500, height: 500, background: 'radial-gradient(circle, rgba(16,185,129,0.06) 0%, transparent 70%)', pointerEvents: 'none' }} />

      <div style={{ width: '100%', maxWidth: 420, animation: 'fadeUp 0.5s cubic-bezier(.22,1,.36,1)' }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <div style={{ width: 52, height: 52, background: 'linear-gradient(135deg,#8B5CF6,#6D28D9)', borderRadius: 16, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26, margin: '0 auto 16px', boxShadow: '0 0 30px rgba(139,92,246,0.4)' }}>⬡</div>
          <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 900, fontSize: 28, background: 'linear-gradient(135deg,#fff,#A78BFA)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            InfluFind
          </div>
          <div style={{ color: T.textFaint, fontSize: 14, marginTop: 6 }}>
            {mode === 'login' ? 'Sign in to your account' : 'Create your brand account'}
          </div>
        </div>

        {/* Card */}
        <div style={{ background: 'rgba(255,255,255,0.04)', backdropFilter: 'blur(20px)', border: `1px solid ${T.border}`, borderRadius: 24, padding: '32px 28px' }}>
          {/* Tab switcher */}
          <div style={{ display: 'flex', background: 'rgba(255,255,255,0.04)', borderRadius: 12, padding: 4, marginBottom: 28 }}>
            {(['login', 'signup'] as const).map(m => (
              <button
                key={m}
                onClick={() => { setMode(m); setErrors({}) }}
                style={{ flex: 1, padding: '9px', borderRadius: 10, border: 'none', background: mode === m ? 'linear-gradient(135deg,#8B5CF6,#6D28D9)' : 'transparent', color: mode === m ? '#fff' : T.textFaint, fontWeight: 600, fontSize: 14, cursor: 'pointer', transition: 'all 0.2s', fontFamily: "'Satoshi',sans-serif" }}
              >
                {m === 'login' ? 'Sign In' : 'Sign Up'}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {mode === 'signup' && (
              <Input
                label="Full Name"
                placeholder="Aarav Mehta"
                value={form.fullName}
                onChange={set('fullName')}
                error={errors.fullName}
                autoComplete="name"
              />
            )}
            <Input
              label="Email"
              type="email"
              placeholder="you@brand.com"
              value={form.email}
              onChange={set('email')}
              error={errors.email}
              autoComplete="email"
            />
            <Input
              label="Password"
              type="password"
              placeholder="••••••••"
              value={form.password}
              onChange={set('password')}
              error={errors.password}
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
            />

            <Btn type="submit" loading={submitting} fullWidth size="lg" style={{ marginTop: 8 }}>
              {mode === 'login' ? 'Sign In' : 'Create Account'}
            </Btn>
          </form>

          {mode === 'login' && (
            <div style={{ textAlign: 'center', marginTop: 16 }}>
              <button
                onClick={async () => {
                  try {
                    await signIn('demo@influfind.com', 'demo123456')
                  } catch {
                    toast.error('Demo account not set up — please sign up.')
                  }
                }}
                style={{ background: 'none', border: 'none', color: T.textFaint, fontSize: 13, cursor: 'pointer', textDecoration: 'underline', fontFamily: "'Satoshi',sans-serif" }}
              >
                Try with demo account
              </button>
            </div>
          )}
        </div>

        <p style={{ textAlign: 'center', color: T.textFaint, fontSize: 12, marginTop: 20 }}>
          By continuing, you agree to our Terms of Service and Privacy Policy.
        </p>
      </div>

      <style>{`
        @keyframes fadeUp { from { opacity:0;transform:translateY(20px) } to { opacity:1;transform:none } }
        @keyframes spin { to { transform:rotate(360deg) } }
      `}</style>
    </div>
  )
}
