import React, { useState } from 'react'
import { generateContent, ContentType } from '@/lib/openai'
import { useContentHistory } from '@/hooks/useContentHistory'
import { GlassCard, Btn, Loader, PageHeader, Chip, T } from '@/components/ui'
import toast from 'react-hot-toast'

const TABS: { id: ContentType; label: string; icon: string }[] = [
  { id: 'hooks', label: 'Hook Ideas', icon: '🪝' },
  { id: 'captions', label: 'Captions', icon: '✍️' },
  { id: 'hashtags', label: 'Hashtags', icon: '#' },
  { id: 'ctas', label: 'CTAs', icon: '▶' },
]

const CALENDAR = [
  { day: 'Mon', date: 7, post: 'Reel: Morning Routine', platform: 'Instagram', status: 'scheduled' },
  { day: 'Tue', date: 8, post: 'Story: BTS Shoot', platform: 'Instagram', status: 'draft' },
  { day: 'Wed', date: 9, post: null, platform: null, status: null },
  { day: 'Thu', date: 10, post: 'Video: 30-Day Review', platform: 'YouTube', status: 'scheduled' },
  { day: 'Fri', date: 11, post: 'Post: Before & After', platform: 'Instagram', status: 'draft' },
  { day: 'Sat', date: 12, post: 'Story: Poll + Q&A', platform: 'Instagram', status: 'idea' },
  { day: 'Sun', date: 13, post: null, platform: null, status: null },
]

const inp: React.CSSProperties = { background: 'rgba(255,255,255,0.05)', border: `1px solid ${T.border}`, borderRadius: 12, color: T.text, padding: '10px 14px', fontSize: 14, outline: 'none', fontFamily: "'Satoshi',sans-serif", width: '100%' }

export const ContentAI: React.FC = () => {
  const { history, saveContent, deleteHistory } = useContentHistory()
  const [tab, setTab] = useState<ContentType | 'calendar' | 'history'>('hooks')
  const [generating, setGenerating] = useState(false)
  const [items, setItems] = useState<string[]>([])
  const [editIdx, setEditIdx] = useState<number | null>(null)
  const [editVal, setEditVal] = useState('')
  const [showHistory, setShowHistory] = useState(false)
  const [params, setParams] = useState({ campaign: 'Summer Glow Collection', brand: 'LumiSkin', tone: 'Aspirational & Relatable', niche: 'Beauty & Skincare' })

  const set = (key: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setParams(p => ({ ...p, [key]: e.target.value }))

  const generate = async () => {
    if (tab === 'calendar' || tab === 'history') return
    setGenerating(true)
    try {
      const result = await generateContent({ ...params, contentType: tab as ContentType, count: tab === 'captions' ? 3 : tab === 'hashtags' ? 4 : 5 })
      setItems(result)
      await saveContent({ campaign_name: params.campaign, brand_name: params.brand, tone: params.tone, content_type: tab as ContentType, generated: result })
      toast.success('Content generated and saved!')
    } catch {
      toast.error('Generation failed. Check your OpenAI key.')
    } finally {
      setGenerating(false)
    }
  }

  const copy = (text: string) => { navigator.clipboard?.writeText(text); toast.success('Copied!') }

  const statusColor: Record<string, string> = { scheduled: T.emerald, draft: T.amber, idea: T.violet }

  return (
    <div>
      <PageHeader title="Content AI Studio" subtitle="Generate scroll-stopping content ideas powered by GPT-4o."
        action={<Chip color={import.meta.env.VITE_OPENAI_API_KEY ? T.emerald : T.amber}>{import.meta.env.VITE_OPENAI_API_KEY ? '● GPT-4o Connected' : '⚠ Using Mock Data'}</Chip>}
      />

      {/* Params */}
      <GlassCard style={{ marginBottom: 24 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,minmax(0,1fr))', gap: 14, alignItems: 'flex-end' }}>
          {[['Campaign', 'campaign', 'Summer Glow Collection'], ['Brand', 'brand', 'LumiSkin'], ['Tone', 'tone', 'Aspirational & Relatable'], ['Niche', 'niche', 'Beauty & Skincare']].map(([l, k, ph]) => (
            <div key={k}>
              <div style={{ fontSize: 11, fontWeight: 700, color: T.textFaint, marginBottom: 8, letterSpacing: 1 }}>{l.toUpperCase()}</div>
              <input value={(params as any)[k]} onChange={set(k)} placeholder={ph} style={inp} />
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
          <Btn onClick={generate} loading={generating} disabled={tab === 'calendar' || tab === 'history'}>
            ✦ Generate with AI
          </Btn>
          <Btn variant="ghost" onClick={() => setShowHistory(!showHistory)}>
            {showHistory ? 'Hide' : 'View'} History ({history.length})
          </Btn>
        </div>
      </GlassCard>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 24, background: 'rgba(255,255,255,0.04)', padding: 5, borderRadius: 16, border: `1px solid ${T.border}`, width: 'fit-content', flexWrap: 'wrap' }}>
        {[...TABS, { id: 'calendar' as any, label: 'Calendar', icon: '📅' }, { id: 'history' as any, label: 'History', icon: '🕒' }].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            style={{ padding: '8px 16px', borderRadius: 12, border: 'none', background: tab === t.id ? 'linear-gradient(135deg,#8B5CF6,#6D28D9)' : 'transparent', color: tab === t.id ? '#fff' : T.textFaint, fontWeight: 600, fontSize: 13, cursor: 'pointer', transition: 'all 0.2s', display: 'flex', alignItems: 'center', gap: 6, fontFamily: "'Satoshi',sans-serif" }}>
            <span style={{ fontSize: 14 }}>{t.icon}</span>{t.label}
          </button>
        ))}
      </div>

      {/* Content Area */}
      {generating && <Loader text="GPT-4o is generating your content…" />}

      {!generating && tab !== 'calendar' && tab !== 'history' && (
        items.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 20px', color: T.textFaint }}>
            <div style={{ fontSize: 48, marginBottom: 16, opacity: 0.3 }}>✦</div>
            <div style={{ fontWeight: 600, fontSize: 16, marginBottom: 8 }}>Ready to generate</div>
            <div style={{ fontSize: 14 }}>Fill in the form above and click "Generate with AI"</div>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: tab === 'hashtags' ? 'repeat(2,minmax(0,1fr))' : 'repeat(2,minmax(0,1fr))', gap: 16 }}>
            {items.map((item, i) => (
              <GlassCard key={i} delay={i * 60}>
                {editIdx === i ? (
                  <div>
                    <textarea value={editVal} onChange={e => setEditVal(e.target.value)} style={{ ...inp, minHeight: 90, resize: 'vertical' }} />
                    <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                      <Btn size="sm" onClick={() => { const updated = [...items]; updated[i] = editVal; setItems(updated); setEditIdx(null) }}>Save</Btn>
                      <Btn size="sm" variant="ghost" onClick={() => setEditIdx(null)}>Cancel</Btn>
                    </div>
                  </div>
                ) : (
                  <div>
                    <p style={{ fontSize: 14, lineHeight: 1.75, color: T.textMuted, marginBottom: 16 }}>{item}</p>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <Btn size="sm" variant="ghost" onClick={() => { setEditIdx(i); setEditVal(item) }}>✎ Edit</Btn>
                      <Btn size="sm" variant="ghost" onClick={() => copy(item)}>⎘ Copy</Btn>
                    </div>
                  </div>
                )}
              </GlassCard>
            ))}
          </div>
        )
      )}

      {!generating && tab === 'calendar' && (
        <GlassCard>
          <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 800, fontSize: 18, marginBottom: 20 }}>
            Week of July 7–13, 2025
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,minmax(0,1fr))', gap: 10 }}>
            {CALENDAR.map(d => (
              <div key={d.day} style={{ background: d.post ? 'rgba(139,92,246,0.08)' : 'rgba(255,255,255,0.02)', borderRadius: 14, padding: '12px 10px', border: d.post ? '1px solid rgba(139,92,246,0.25)' : `1px dashed ${T.border}`, minHeight: 130 }}>
                <div style={{ fontWeight: 800, fontSize: 12, color: T.textFaint }}>{d.day}</div>
                <div style={{ fontFamily: "'Cabinet Grotesk',sans-serif", fontWeight: 900, fontSize: 18, marginBottom: 10 }}>{d.date}</div>
                {d.post ? (
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 600, color: T.text, marginBottom: 8, lineHeight: 1.4 }}>{d.post}</div>
                    <Chip color={d.platform === 'Instagram' ? '#EC4899' : '#FF0000'} size="sm">{d.platform}</Chip>
                    <div style={{ marginTop: 5 }}><Chip color={statusColor[d.status!] || T.textFaint} size="sm">{d.status}</Chip></div>
                  </div>
                ) : <div style={{ fontSize: 22, color: 'rgba(255,255,255,0.08)', marginTop: 14, textAlign: 'center' }}>+</div>}
              </div>
            ))}
          </div>
        </GlassCard>
      )}

      {!generating && tab === 'history' && (
        <div>
          {history.length === 0 ? (
            <div style={{ textAlign: 'center', padding: 60, color: T.textFaint }}>
              <div style={{ fontSize: 40, marginBottom: 12, opacity: 0.3 }}>🕒</div>
              <div style={{ fontWeight: 600 }}>No history yet</div>
              <div style={{ fontSize: 13, marginTop: 6 }}>Generated content will appear here</div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {history.map(h => (
                <GlassCard key={h.id}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
                    <Chip color={T.violet}>{h.content_type}</Chip>
                    <span style={{ fontSize: 13, fontWeight: 600 }}>{h.campaign_name} · {h.brand_name}</span>
                    <span style={{ marginLeft: 'auto', fontSize: 12, color: T.textFaint }}>{new Date(h.created_at).toLocaleDateString()}</span>
                    <Btn size="sm" variant="ghost" onClick={() => deleteHistory(h.id)}>Delete</Btn>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    {(h.generated as string[]).slice(0, 2).map((item, i) => (
                      <div key={i} style={{ fontSize: 13, color: T.textMuted, padding: '8px 12px', background: 'rgba(255,255,255,0.03)', borderRadius: 8, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 }}>
                        <span style={{ lineHeight: 1.5 }}>{item.slice(0, 120)}{item.length > 120 ? '…' : ''}</span>
                        <button onClick={() => copy(item)} style={{ background: 'none', border: 'none', color: T.textFaint, cursor: 'pointer', fontSize: 14, flexShrink: 0 }}>⎘</button>
                      </div>
                    ))}
                    {h.generated.length > 2 && <div style={{ fontSize: 12, color: T.textFaint }}>+{h.generated.length - 2} more items</div>}
                  </div>
                </GlassCard>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
