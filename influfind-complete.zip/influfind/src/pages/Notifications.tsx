import React, { useState } from 'react'
import { useNotifications } from '@/hooks/useNotifications'
import { GlassCard, Btn, Loader, EmptyState, Chip, PageHeader, T } from '@/components/ui'

export const Notifications: React.FC = () => {
  const { notifications, loading, markRead, markAllRead, unreadCount } = useNotifications()
  const [filter, setFilter] = useState<'all' | 'unread'>('all')

  const shown = filter === 'unread' ? notifications.filter(n => !n.is_read) : notifications

  const typeColor: Record<string, string> = {
    match: T.violet, campaign: T.emerald, message: T.sky,
    reach: T.amber, billing: '#F97316', system: T.textFaint,
  }

  if (loading) return <Loader text="Loading notifications…" />

  return (
    <div>
      <PageHeader
        title="Notifications"
        subtitle={`${unreadCount} unread alert${unreadCount !== 1 ? 's' : ''}`}
        action={
          <div style={{ display: 'flex', gap: 10 }}>
            <div style={{ display: 'flex', background: 'rgba(255,255,255,0.04)', border: `1px solid ${T.border}`, borderRadius: 12, overflow: 'hidden' }}>
              {(['all', 'unread'] as const).map(f => (
                <button key={f} onClick={() => setFilter(f)}
                  style={{ padding: '9px 18px', border: 'none', background: filter === f ? 'rgba(139,92,246,0.3)' : 'transparent', color: filter === f ? '#fff' : T.textFaint, fontWeight: 600, fontSize: 13, cursor: 'pointer', transition: 'all 0.2s', fontFamily: "'Satoshi',sans-serif" }}>
                  {f.charAt(0).toUpperCase() + f.slice(1)}
                </button>
              ))}
            </div>
            {unreadCount > 0 && <Btn variant="ghost" size="sm" onClick={markAllRead}>Mark all read</Btn>}
          </div>
        }
      />

      <div style={{ maxWidth: 720 }}>
        {shown.length === 0 ? (
          <EmptyState icon="◇" title="All caught up!" description={filter === 'unread' ? 'No unread notifications.' : 'No notifications yet.'} />
        ) : (
          shown.map((n, i) => (
            <div
              key={n.id}
              onClick={() => !n.is_read && markRead(n.id)}
              className="animate-fade-up"
              style={{
                display: 'flex', gap: 16, padding: '18px 22px',
                background: n.is_read ? 'rgba(255,255,255,0.02)' : 'rgba(139,92,246,0.08)',
                borderRadius: 16,
                border: n.is_read ? `1px solid ${T.border}` : `1px solid ${n.color}33`,
                marginBottom: 10, cursor: n.is_read ? 'default' : 'pointer',
                transition: 'all 0.2s',
                animationDelay: `${i * 40}ms`, animationFillMode: 'both',
              }}
              onMouseEnter={e => !n.is_read && ((e.currentTarget as HTMLDivElement).style.transform = 'translateY(-2px)')}
              onMouseLeave={e => ((e.currentTarget as HTMLDivElement).style.transform = 'none')}
            >
              <div style={{ width: 46, height: 46, borderRadius: 14, background: n.color + '22', border: `1px solid ${n.color}44`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, color: n.color, flexShrink: 0 }}>
                {n.icon}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 5, flexWrap: 'wrap' }}>
                  <span style={{ fontWeight: 700, fontSize: 14 }}>{n.title}</span>
                  <Chip color={typeColor[n.type] || T.textFaint} size="sm">{n.type}</Chip>
                  {!n.is_read && <span style={{ width: 7, height: 7, background: T.violet, borderRadius: '50%', display: 'inline-block', boxShadow: `0 0 8px ${T.violet}` }} />}
                </div>
                <p style={{ fontSize: 13, color: T.textMuted, lineHeight: 1.6, marginBottom: 6 }}>{n.message}</p>
                <div style={{ fontSize: 11, color: T.textFaint }}>
                  {new Date(n.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
