import { loadStripe } from '@stripe/stripe-js'
import { supabase } from './supabase'

const stripePublicKey = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY

export const stripe = stripePublicKey ? loadStripe(stripePublicKey) : null

// ─── Stripe Price IDs ─────────────────────────────────────────────────────
// Replace these with your actual Stripe Price IDs from dashboard.stripe.com
export const PLANS = {
  starter: {
    name: 'Starter',
    price: '$19',
    priceId: 'price_starter_monthly', // Replace with real Stripe Price ID
    features: ['50 influencer searches/mo', '3 active campaigns', 'Basic AI content', 'Email support'],
  },
  pro: {
    name: 'Pro',
    price: '$49',
    priceId: 'price_pro_monthly', // Replace with real Stripe Price ID
    features: ['Unlimited searches', '10 active campaigns', 'Full AI content studio', 'Priority support', 'Analytics dashboard'],
    popular: true,
  },
  enterprise: {
    name: 'Enterprise',
    price: '$149',
    priceId: 'price_enterprise_monthly', // Replace with real Stripe Price ID
    features: ['Everything unlimited', '25 campaigns', 'Custom AI training', 'Dedicated manager', 'White-label reports'],
  },
} as const

export type PlanKey = keyof typeof PLANS

// ─── Create Checkout Session ──────────────────────────────────────────────
// In production this should go through a Supabase Edge Function / backend
// to keep your Stripe secret key server-side.
// See: supabase/functions/create-checkout/index.ts (scaffold below)
export async function createCheckoutSession(planKey: PlanKey): Promise<void> {
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) throw new Error('Not authenticated')

  const plan = PLANS[planKey]

  // Example: call your Supabase Edge Function
  const { data, error } = await supabase.functions.invoke('create-checkout', {
    body: {
      priceId: plan.priceId,
      userId: user.id,
      userEmail: user.email,
      successUrl: `${window.location.origin}/settings?tab=subscription&success=true`,
      cancelUrl: `${window.location.origin}/settings?tab=subscription`,
    },
  })

  if (error) throw error

  // Redirect to Stripe Checkout
  const stripeInstance = await stripe
  if (stripeInstance && data?.sessionId) {
    await stripeInstance.redirectToCheckout({ sessionId: data.sessionId })
  } else {
    // Fallback: open Stripe payment link directly
    window.open(`https://buy.stripe.com/your-payment-link?prefilled_email=${user.email}`, '_blank')
  }
}

// ─── Open Customer Portal ─────────────────────────────────────────────────
export async function openCustomerPortal(): Promise<void> {
  const { data, error } = await supabase.functions.invoke('create-portal', {
    body: { returnUrl: window.location.href },
  })
  if (error) throw error
  if (data?.url) window.open(data.url, '_blank')
}

// ─── Supabase Edge Function scaffolds ────────────────────────────────────
// Create these files in your repo at:
// supabase/functions/create-checkout/index.ts
// supabase/functions/create-portal/index.ts
// supabase/functions/stripe-webhook/index.ts
// See README.md for full implementation guide.
