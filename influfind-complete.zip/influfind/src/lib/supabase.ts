import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables. Check your .env file.')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
  },
  realtime: {
    params: { eventsPerSecond: 10 },
  },
})

// ─── Database Types ────────────────────────────────────────────────────────
export type Profile = {
  id: string
  full_name: string | null
  brand_name: string | null
  website: string | null
  avatar_url: string | null
  bio: string | null
  plan: 'free' | 'starter' | 'pro' | 'enterprise'
  stripe_customer_id: string | null
  subscription_status: string
  created_at: string
  updated_at: string
}

export type Influencer = {
  id: string
  name: string
  handle: string
  avatar_url: string | null
  cover_url: string | null
  bio: string | null
  niche: string
  platform: string
  followers: number
  followers_display: string
  engagement_rate: number
  avg_views: number
  avg_views_display: string
  location: string | null
  rating: number
  fee_per_post: number
  verified: boolean
  trend_percent: string | null
  accent_color: string
  tags: string[]
  is_active: boolean
  created_at: string
}

export type Campaign = {
  id: string
  user_id: string
  name: string
  brand: string
  description: string | null
  status: 'pending' | 'active' | 'completed' | 'cancelled' | 'paused'
  influencer_id: string | null
  influencer?: Influencer
  expected_reach: number
  actual_reach: number
  budget: number
  spent: number
  progress: number
  deadline: string | null
  deliverables_count: number
  deliverables_submitted: number
  notes: string | null
  created_at: string
  updated_at: string
}

export type Message = {
  id: string
  campaign_id: string
  sender_id: string
  sender_name: string
  sender_avatar: string | null
  content: string
  is_read: boolean
  created_at: string
}

export type ContentHistory = {
  id: string
  user_id: string
  campaign_name: string | null
  brand_name: string | null
  tone: string | null
  content_type: 'hooks' | 'captions' | 'hashtags' | 'ctas' | 'calendar'
  prompt: string | null
  generated: string[]
  created_at: string
}

export type Notification = {
  id: string
  user_id: string
  type: 'match' | 'campaign' | 'message' | 'reach' | 'billing' | 'system'
  title: string
  message: string
  is_read: boolean
  action_url: string | null
  icon: string
  color: string
  created_at: string
}

export type Deliverable = {
  id: string
  campaign_id: string
  uploader_id: string
  file_name: string
  file_url: string
  file_type: string | null
  file_size: number | null
  status: 'pending' | 'approved' | 'rejected'
  notes: string | null
  created_at: string
}
