import OpenAI from 'openai'

const apiKey = import.meta.env.VITE_OPENAI_API_KEY

// Note: In production, move OpenAI calls to a Supabase Edge Function
// to keep your API key server-side only.
const openai = apiKey ? new OpenAI({ apiKey, dangerouslyAllowBrowser: true }) : null

export type ContentType = 'hooks' | 'captions' | 'hashtags' | 'ctas'

interface GenerateParams {
  campaign: string
  brand: string
  tone: string
  niche?: string
  contentType: ContentType
  count?: number
}

const SYSTEM_PROMPT = `You are InfluFind's AI content strategist specializing in viral influencer marketing content.
You create platform-native, scroll-stopping content that converts.
Always respond with a JSON array of strings only — no markdown, no explanations, no extra keys.`

const PROMPTS: Record<ContentType, (p: GenerateParams) => string> = {
  hooks: ({ campaign, brand, tone, count = 5 }) =>
    `Generate ${count} viral hook ideas for an influencer campaign.
Campaign: "${campaign}" | Brand: "${brand}" | Tone: ${tone}
Rules: Each hook should stop the scroll in first 2 seconds. Mix curiosity, FOMO, relatability.
Return JSON array of ${count} hook strings.`,

  captions: ({ campaign, brand, tone, count = 3 }) =>
    `Write ${count} Instagram/YouTube caption options for an influencer campaign.
Campaign: "${campaign}" | Brand: "${brand}" | Tone: ${tone}
Rules: Include storytelling, emotion, clear CTA, relevant emojis, hashtag placeholders.
Each caption 100-200 words. Return JSON array of ${count} caption strings.`,

  hashtags: ({ campaign, brand, tone, niche, count = 4 }) =>
    `Generate ${count} strategic hashtag sets for influencer content.
Campaign: "${campaign}" | Brand: "${brand}" | Niche: ${niche || 'General'} | Tone: ${tone}
Rules: Mix mega (1M+), macro (100K-1M), micro (10K-100K) hashtags. 8-12 per set.
Return JSON array of ${count} hashtag set strings.`,

  ctas: ({ campaign, brand, count = 4 }) =>
    `Write ${count} compelling call-to-action lines for an influencer campaign.
Campaign: "${campaign}" | Brand: "${brand}"
Rules: Action-oriented, urgent but not pushy, include emoji. Vary the style.
Return JSON array of ${count} CTA strings.`,
}

export async function generateContent(params: GenerateParams): Promise<string[]> {
  if (!openai) {
    // Return mock data if no API key configured
    return getMockContent(params.contentType)
  }

  const prompt = PROMPTS[params.contentType](params)

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: prompt },
      ],
      temperature: 0.85,
      max_tokens: 1500,
      response_format: { type: 'json_object' },
    })

    const raw = response.choices[0]?.message?.content || '{"items":[]}'
    const parsed = JSON.parse(raw)
    // Handle various response shapes
    const items = parsed.items || parsed.hooks || parsed.captions ||
      parsed.hashtags || parsed.ctas || parsed.content || []
    return Array.isArray(items) ? items : Object.values(parsed).flat() as string[]
  } catch (err) {
    console.error('OpenAI error:', err)
    return getMockContent(params.contentType)
  }
}

function getMockContent(type: ContentType): string[] {
  const mock: Record<ContentType, string[]> = {
    hooks: [
      '"Wait — this changed my entire routine"',
      '"I tested this for 30 days. Here\'s the truth."',
      '"POV: You finally found the product you\'ve been looking for"',
      '"Stop scrolling — this is actually worth your time"',
      '"No one talks about this, but it\'s a total game changer"',
    ],
    captions: [
      'Glowing from the inside out ✨ This summer I made a promise to my skin — and the results are honestly wild. Three weeks in and I can\'t imagine going back. Link in bio for my full routine + exclusive discount 🌞 #SkinFirst #SummerGlow',
      'Real talk: I\'ve tried everything. Nothing clicked until this. My skin has never felt this hydrated going into summer. Drop a 🙋 if you want the full breakdown!',
      'Some things just speak for themselves. 60 seconds in the morning. That\'s all it takes. Tag someone who needs to see this 👇',
    ],
    hashtags: [
      '#SummerGlow #SkincareTok #GlowUp #LumiSkin #SkincareRoutine #SkinFirst #BeautyTips',
      '#HydrationStation #NaturalGlow #CleanBeauty #MorningRoutine #HealthySkin #SelfCare',
      '#GlowingSkin #BeautySecrets #SkincareJunkie #GlassKin #SkinGoals #BeautyRoutine',
      '#SkincareCommunity #NaturalBeauty #SkincareObsessed #GlowGetters #CleanSkincare',
    ],
    ctas: [
      '🔗 Link in bio — use GLOW20 for 20% off your first order!',
      '💬 Drop your skin type below and I\'ll tell you which formula is right for you!',
      '📲 Save this post and come back in 2 weeks to tell me your results!',
      '👆 Click the link to shop the exact routine I use every single morning.',
    ],
  }
  return mock[type] || []
}
