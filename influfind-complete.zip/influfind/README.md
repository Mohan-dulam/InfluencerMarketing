# ⬡ InfluFind — Influencer Marketing SaaS

A full-stack influencer marketing platform built with React, Supabase, OpenAI, and Stripe.

---

## 🗂 Project Structure

```
influfind/
├── public/
│   └── favicon.svg
├── src/
│   ├── components/
│   │   ├── ui/            # Reusable UI primitives (Button, Card, Input, etc.)
│   │   ├── layout/        # Sidebar, AppLayout
│   │   └── charts/        # Recharts wrappers (ReachAreaChart, etc.)
│   ├── context/
│   │   └── AuthContext.tsx  # Supabase auth + profile state
│   ├── hooks/
│   │   ├── useInfluencers.ts
│   │   ├── useCampaigns.ts
│   │   ├── useMessages.ts
│   │   ├── useDeliverables.ts
│   │   ├── useNotifications.ts
│   │   └── useContentHistory.ts
│   ├── lib/
│   │   ├── supabase.ts    # Supabase client + types
│   │   ├── openai.ts      # GPT-4o content generation
│   │   └── stripe.ts      # Stripe checkout + portal
│   ├── pages/
│   │   ├── Auth.tsx
│   │   ├── Dashboard.tsx
│   │   ├── Discover.tsx
│   │   ├── ContentAI.tsx
│   │   ├── Campaigns.tsx
│   │   ├── Notifications.tsx
│   │   └── Settings.tsx
│   ├── main.tsx
│   └── index.css
├── supabase/
│   └── migrations/
│       └── 001_initial_schema.sql
├── .env.example
├── package.json
├── tailwind.config.js
├── tsconfig.json
└── vite.config.ts
```

---

## ⚡ Step-by-Step: From Zero to Running Locally

### STEP 1 — Prerequisites

Make sure you have these installed:
```bash
node --version    # Must be v18 or higher
git --version     # Any recent version
```

If Node is not installed, download it from https://nodejs.org (LTS version).

---

### STEP 2 — Clone / Set up the project

**Option A — You already have the files (from Claude):**
```bash
# Navigate to the project folder
cd influfind

# Install all dependencies
npm install
```

**Option B — Push to GitHub first, then clone:**
```bash
# 1. Create a new repo at github.com (click New Repository, name it "influfind")
# 2. In your project folder:
git init
git add .
git commit -m "Initial commit — InfluFind SaaS"
git remote add origin https://github.com/YOUR_USERNAME/influfind.git
git branch -M main
git push -u origin main

# 3. Clone on any machine
git clone https://github.com/YOUR_USERNAME/influfind.git
cd influfind
npm install
```

---

### STEP 3 — Set up Supabase

1. Go to **https://supabase.com** → Create a free account
2. Click **"New Project"** → Enter a name (e.g., `influfind`) → Choose a region → Set a strong database password → **Create Project**
3. Wait ~2 minutes for the project to spin up
4. Go to **Project Settings → API** (left sidebar)
5. Copy:
   - **Project URL** (looks like `https://xxxxxxxxxxxx.supabase.co`)
   - **anon/public** key (long string starting with `eyJ...`)

6. Run the database schema:
   - Go to **SQL Editor** (left sidebar)
   - Click **"New Query"**
   - Open `supabase/migrations/001_initial_schema.sql` from this project
   - Paste the entire contents → Click **"Run"**
   - You should see "Success. No rows returned"

7. Create Storage Buckets:
   - Go to **Storage** (left sidebar) → **New bucket**
   - Create bucket named `avatars` → Check "Public bucket" → Save
   - Create bucket named `deliverables` → Leave as private → Save
   - Create bucket named `influencer-covers` → Check "Public bucket" → Save

---

### STEP 4 — Set up OpenAI (for AI content generation)

1. Go to **https://platform.openai.com** → Sign up / Log in
2. Go to **API Keys** → Click **"Create new secret key"**
3. Copy the key (starts with `sk-...`)
4. Make sure you have credits — go to Billing and add a payment method
5. The app uses `gpt-4o-mini` by default (cheapest, fastest)

> **Note:** If you skip this step, the app still works using built-in mock content. The AI key is optional.

---

### STEP 5 — Set up Stripe (for billing/subscriptions)

1. Go to **https://dashboard.stripe.com** → Sign up / Log in
2. Make sure you're in **Test Mode** (toggle in top-right)
3. Go to **API Keys** → Copy the **Publishable key** (starts with `pk_test_...`)
4. Create your products:
   - Go to **Products** → **Add Product**
   - Create "Starter Plan" — $19/month recurring
   - Create "Pro Plan" — $49/month recurring
   - Create "Enterprise Plan" — $149/month recurring
5. Copy each product's **Price ID** (starts with `price_...`)
6. Update `src/lib/stripe.ts` — replace the `priceId` values in the `PLANS` object

For the Stripe webhook (to update subscriptions in DB), you'll need a backend.
See the **Edge Functions** section below.

---

### STEP 6 — Configure environment variables

```bash
# Copy the example file
cp .env.example .env

# Open .env in any text editor and fill in your values:
```

Edit `.env`:
```env
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

VITE_OPENAI_API_KEY=sk-proj-...

VITE_STRIPE_PUBLISHABLE_KEY=pk_test_...

VITE_APP_URL=http://localhost:5173
```

> ⚠️ NEVER commit `.env` to GitHub. It is in `.gitignore` for safety.

---

### STEP 7 — Run the app locally

```bash
npm run dev
```

Open **http://localhost:5173** in your browser.

You should see the InfluFind login screen. Sign up with any email and password to create your account!

---

## 🌐 Deploy to Vercel (Production)

### 1. Push code to GitHub (if not done already)
```bash
git add .
git commit -m "Ready for deployment"
git push origin main
```

### 2. Deploy on Vercel
1. Go to **https://vercel.com** → Sign in with GitHub
2. Click **"Add New Project"** → Select your `influfind` repository
3. Vercel auto-detects Vite — no build config needed
4. Click **"Environment Variables"** → Add all variables from your `.env` file:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
   - `VITE_OPENAI_API_KEY`
   - `VITE_STRIPE_PUBLISHABLE_KEY`
   - `VITE_APP_URL` → set this to your Vercel URL (e.g., `https://influfind.vercel.app`)
5. Click **"Deploy"** → Wait ~2 minutes

### 3. Update Supabase Auth settings
- Go to Supabase → **Authentication → URL Configuration**
- Add your Vercel URL to **Site URL** and **Redirect URLs**
- Example: `https://influfind.vercel.app`

---

## 🔧 Supabase Edge Functions (for Stripe webhooks)

Create these files in `supabase/functions/`:

### `supabase/functions/create-checkout/index.ts`
```typescript
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import Stripe from 'https://esm.sh/stripe@13.11.0?target=deno'

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', { apiVersion: '2023-10-16' })

serve(async (req) => {
  const { priceId, userId, userEmail, successUrl, cancelUrl } = await req.json()

  const session = await stripe.checkout.sessions.create({
    customer_email: userEmail,
    line_items: [{ price: priceId, quantity: 1 }],
    mode: 'subscription',
    success_url: successUrl,
    cancel_url: cancelUrl,
    metadata: { userId },
  })

  return new Response(JSON.stringify({ sessionId: session.id }), {
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  })
})
```

Deploy with:
```bash
npx supabase functions deploy create-checkout --project-ref YOUR_PROJECT_REF
npx supabase secrets set STRIPE_SECRET_KEY=sk_test_your_key
```

---

## 🗄️ Supabase Schema Summary

| Table | Purpose |
|-------|---------|
| `profiles` | User accounts (extends auth.users) |
| `influencers` | Creator database with metadata |
| `campaigns` | Brand campaigns with status & progress |
| `messages` | Real-time campaign chat messages |
| `content_history` | AI-generated content saved per user |
| `deliverables` | Files uploaded for campaigns |
| `notifications` | Real-time alerts and updates |
| `subscription_events` | Stripe billing event log |

All tables have **Row Level Security (RLS)** enabled — users can only access their own data.

**Realtime** is enabled on: `messages`, `notifications`, `campaigns`

---

## 🔑 Environment Variables Reference

| Variable | Where to get it | Required |
|----------|----------------|----------|
| `VITE_SUPABASE_URL` | Supabase → Settings → API | ✅ Yes |
| `VITE_SUPABASE_ANON_KEY` | Supabase → Settings → API | ✅ Yes |
| `VITE_OPENAI_API_KEY` | platform.openai.com → API Keys | ❌ Optional (uses mock) |
| `VITE_STRIPE_PUBLISHABLE_KEY` | dashboard.stripe.com → API Keys | ❌ Optional |
| `VITE_APP_URL` | Your deployed URL | ❌ Optional |

---

## 🛠️ Common Issues & Fixes

**"Missing Supabase environment variables"**
→ Make sure your `.env` file exists and has the correct variable names starting with `VITE_`

**"Failed to fetch influencers"**
→ Run the SQL migration in Supabase SQL Editor. Check that RLS policies are set up.

**Login not working**
→ In Supabase → Authentication → Settings → disable "Confirm email" for local testing

**Stripe checkout not opening**
→ Make sure you've replaced the fake `price_...` IDs in `src/lib/stripe.ts` with real Stripe Price IDs

**Storage upload fails**
→ Create the `avatars` and `deliverables` buckets in Supabase Storage

**Build fails on Vercel**
→ Make sure all environment variables are set in Vercel project settings

---

## 📦 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18 + TypeScript + Vite |
| Styling | Tailwind CSS + custom glassmorphism |
| Routing | React Router v6 |
| Auth | Supabase Auth (email/password) |
| Database | Supabase PostgreSQL + RLS |
| Realtime | Supabase Realtime (WebSockets) |
| Storage | Supabase Storage (S3-compatible) |
| AI | OpenAI GPT-4o-mini |
| Billing | Stripe Checkout + Customer Portal |
| Charts | Recharts |
| Notifications | react-hot-toast |
| State | React hooks + Zustand (ready) |
| Deploy | Vercel (recommended) |

---

## 🚀 Quick Commands Reference

```bash
npm run dev        # Start local dev server at localhost:5173
npm run build      # Build for production
npm run preview    # Preview production build locally
npm run lint       # Run ESLint
```

---

Made with ⬡ by InfluFind
