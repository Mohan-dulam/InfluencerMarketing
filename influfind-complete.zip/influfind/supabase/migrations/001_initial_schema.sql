-- ════════════════════════════════════════════════════════════
-- InfluFind — Complete Supabase Schema
-- Run this in Supabase SQL Editor (Dashboard → SQL Editor → New Query)
-- ════════════════════════════════════════════════════════════

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── PROFILES ─────────────────────────────────────────────────────────────
-- Extends Supabase auth.users
CREATE TABLE IF NOT EXISTS profiles (
  id            UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name     TEXT,
  brand_name    TEXT,
  website       TEXT,
  avatar_url    TEXT,
  bio           TEXT,
  plan          TEXT DEFAULT 'free' CHECK (plan IN ('free', 'starter', 'pro', 'enterprise')),
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  subscription_status TEXT DEFAULT 'inactive',
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, full_name, avatar_url)
  VALUES (
    NEW.id,
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'avatar_url'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ─── INFLUENCERS ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS influencers (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          TEXT NOT NULL,
  handle        TEXT NOT NULL UNIQUE,
  avatar_url    TEXT,
  cover_url     TEXT,
  bio           TEXT,
  niche         TEXT NOT NULL,
  platform      TEXT NOT NULL CHECK (platform IN ('Instagram','YouTube','TikTok','Twitter','LinkedIn')),
  followers     BIGINT DEFAULT 0,
  followers_display TEXT,
  engagement_rate DECIMAL(5,2) DEFAULT 0,
  avg_views     BIGINT DEFAULT 0,
  avg_views_display TEXT,
  location      TEXT,
  rating        DECIMAL(3,2) DEFAULT 0,
  fee_per_post  INTEGER DEFAULT 0,
  verified      BOOLEAN DEFAULT FALSE,
  trend_percent TEXT,
  accent_color  TEXT DEFAULT '#8B5CF6',
  tags          TEXT[] DEFAULT '{}',
  is_active     BOOLEAN DEFAULT TRUE,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ─── CAMPAIGNS ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS campaigns (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  brand           TEXT NOT NULL,
  description     TEXT,
  status          TEXT DEFAULT 'pending' CHECK (status IN ('pending','active','completed','cancelled','paused')),
  influencer_id   UUID REFERENCES influencers(id) ON DELETE SET NULL,
  expected_reach  BIGINT DEFAULT 0,
  actual_reach    BIGINT DEFAULT 0,
  budget          INTEGER DEFAULT 0,
  spent           INTEGER DEFAULT 0,
  progress        INTEGER DEFAULT 0 CHECK (progress BETWEEN 0 AND 100),
  deadline        DATE,
  deliverables_count INTEGER DEFAULT 0,
  deliverables_submitted INTEGER DEFAULT 0,
  notes           TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─── MESSAGES ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS messages (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  campaign_id   UUID NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
  sender_id     UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  sender_name   TEXT NOT NULL,
  sender_avatar TEXT,
  content       TEXT NOT NULL,
  is_read       BOOLEAN DEFAULT FALSE,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ─── CONTENT HISTORY ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS content_history (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  campaign_name TEXT,
  brand_name    TEXT,
  tone          TEXT,
  content_type  TEXT CHECK (content_type IN ('hooks','captions','hashtags','ctas','calendar')),
  prompt        TEXT,
  generated     JSONB NOT NULL DEFAULT '[]',
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ─── DELIVERABLES ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS deliverables (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  campaign_id   UUID NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
  uploader_id   UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  file_name     TEXT NOT NULL,
  file_url      TEXT NOT NULL,
  file_type     TEXT,
  file_size     BIGINT,
  status        TEXT DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  notes         TEXT,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ─── NOTIFICATIONS ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type          TEXT CHECK (type IN ('match','campaign','message','reach','billing','system')),
  title         TEXT NOT NULL,
  message       TEXT NOT NULL,
  is_read       BOOLEAN DEFAULT FALSE,
  action_url    TEXT,
  icon          TEXT DEFAULT '◇',
  color         TEXT DEFAULT '#8B5CF6',
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ─── SUBSCRIPTIONS ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS subscription_events (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id               UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  stripe_event_id       TEXT UNIQUE,
  stripe_session_id     TEXT,
  stripe_subscription_id TEXT,
  plan                  TEXT,
  amount                INTEGER,
  currency              TEXT DEFAULT 'usd',
  status                TEXT,
  created_at            TIMESTAMPTZ DEFAULT NOW()
);

-- ─── STORAGE BUCKETS ──────────────────────────────────────────────────────
-- Run these in Supabase Dashboard → Storage
-- Or uncomment and run:
-- INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true);
-- INSERT INTO storage.buckets (id, name, public) VALUES ('deliverables', 'deliverables', false);
-- INSERT INTO storage.buckets (id, name, public) VALUES ('influencer-covers', 'influencer-covers', true);

-- ─── ROW LEVEL SECURITY ───────────────────────────────────────────────────
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE deliverables ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscription_events ENABLE ROW LEVEL SECURITY;

-- Profiles
CREATE POLICY "Users can view own profile" ON profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);

-- Influencers (public read)
ALTER TABLE influencers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view influencers" ON influencers FOR SELECT USING (true);

-- Campaigns
CREATE POLICY "Users can view own campaigns" ON campaigns FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create campaigns" ON campaigns FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own campaigns" ON campaigns FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own campaigns" ON campaigns FOR DELETE USING (auth.uid() = user_id);

-- Messages
CREATE POLICY "Users can view campaign messages" ON messages FOR SELECT
  USING (campaign_id IN (SELECT id FROM campaigns WHERE user_id = auth.uid()));
CREATE POLICY "Users can send messages" ON messages FOR INSERT
  WITH CHECK (auth.uid() = sender_id);

-- Content history
CREATE POLICY "Users can view own content" ON content_history FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create content" ON content_history FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Deliverables
CREATE POLICY "Users can view campaign deliverables" ON deliverables FOR SELECT
  USING (campaign_id IN (SELECT id FROM campaigns WHERE user_id = auth.uid()));
CREATE POLICY "Users can upload deliverables" ON deliverables FOR INSERT WITH CHECK (auth.uid() = uploader_id);

-- Notifications
CREATE POLICY "Users can view own notifications" ON notifications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can update own notifications" ON notifications FOR UPDATE USING (auth.uid() = user_id);

-- ─── REALTIME ────────────────────────────────────────────────────────────
ALTER PUBLICATION supabase_realtime ADD TABLE messages;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE campaigns;

-- ─── SEED DATA — INFLUENCERS ──────────────────────────────────────────────
INSERT INTO influencers (name, handle, avatar_url, cover_url, bio, niche, platform, followers, followers_display, engagement_rate, avg_views, avg_views_display, location, rating, fee_per_post, verified, trend_percent, accent_color, tags) VALUES
('Priya Sharma', '@priya.creates', 'https://images.unsplash.com/photo-1494790108755-2616b612b5bc?w=120&h=120&fit=crop&crop=face', 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=600&h=300&fit=crop', 'Fashion-forward content creator. Brand collab: priya@email.com', 'Fashion & Lifestyle', 'Instagram', 1200000, '1.2M', 4.80, 340000, '340K', 'Mumbai', 4.9, 2400, true, '+12%', '#EC4899', ARRAY['fashion','lifestyle','beauty']),
('Arjun Mehta', '@arjunfitlife', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&h=120&fit=crop&crop=face', 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&h=300&fit=crop', 'Helping 1M+ people live healthier through science-backed fitness content.', 'Fitness & Health', 'YouTube', 890000, '890K', 6.20, 210000, '210K', 'Delhi', 4.7, 1800, true, '+8%', '#10B981', ARRAY['fitness','health','nutrition']),
('Sneha Patel', '@snehacooks', 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=120&h=120&fit=crop&crop=face', 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=600&h=300&fit=crop', 'Food explorer. 50 countries. 1000 recipes. Let''s collaborate!', 'Food & Travel', 'Instagram', 560000, '560K', 5.40, 120000, '120K', 'Bangalore', 4.6, 900, false, '+21%', '#F59E0B', ARRAY['food','travel','recipes']),
('Rohan Das', '@rohantech', 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&h=120&fit=crop&crop=face', 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&h=300&fit=crop', 'Tech reviews, gaming content, and digital lifestyle for 2M+ subscribers.', 'Tech & Gaming', 'YouTube', 2100000, '2.1M', 3.90, 680000, '680K', 'Hyderabad', 4.8, 4200, true, '+5%', '#38BDF8', ARRAY['tech','gaming','reviews']),
('Kavya Nair', '@kavya.beauty', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&h=120&fit=crop&crop=face', 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=600&h=300&fit=crop', 'Skincare junkie. Honest reviews only. Cruelty-free advocate.', 'Beauty & Skincare', 'Instagram', 780000, '780K', 7.10, 190000, '190K', 'Chennai', 4.9, 1500, true, '+34%', '#A78BFA', ARRAY['beauty','skincare','makeup']),
('Vikram Singh', '@vikram.adventure', 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&h=120&fit=crop&crop=face', 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=300&fit=crop', 'Adventure seeker. Backpacking the world one story at a time.', 'Travel & Adventure', 'YouTube', 1500000, '1.5M', 5.00, 420000, '420K', 'Jaipur', 4.5, 3100, true, '+17%', '#F97316', ARRAY['travel','adventure','outdoors']);

-- ─── HELPFUL FUNCTIONS ───────────────────────────────────────────────────
-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER campaigns_updated_at BEFORE UPDATE ON campaigns
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
